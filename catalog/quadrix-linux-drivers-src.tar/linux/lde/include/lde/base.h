/* SPDX-License-Identifier: GPL-2.0 */
/* Quadrix LDE: общие средства ядра Linux (компилятор, память, печать,
 * время, блокировки, отложенная работа). Драйверы выполняются в одном
 * потоке процесса lxdrv: обработчик прерывания вызывается из главного
 * цикла, поэтому блокировки — пустые операции. */
#ifndef _LDE_BASE_H
#define _LDE_BASE_H

#include <linux/types.h>
#include <linux/const.h>
#include <linux/stdarg.h>
#include <lde/qx.h>

/* ----- компилятор ----- */
#define __init
#define __exit
#define __initdata
#define __initconst
#define __exit_p(x) x
#define __devinit
#define __user
#define __iomem
#define __rcu
#define __percpu
#define __force
#define __must_check
#define __read_mostly
#define __cold
#define __maybe_unused __attribute__((unused))
#define __always_unused __attribute__((unused))
#define __used __attribute__((used))
#define __packed __attribute__((packed))
#define __aligned(x) __attribute__((aligned(x)))
#define __always_inline inline __attribute__((always_inline))
#define noinline __attribute__((noinline))
#define __printf(a, b) __attribute__((format(printf, a, b)))
#define __weak __attribute__((weak))
#define __noreturn __attribute__((noreturn))
#define __counted_by(m)
#define __nonstring
#define fallthrough __attribute__((__fallthrough__))
#define likely(x) __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)
#define barrier() __asm__ __volatile__("" ::: "memory")
#define mb() __asm__ __volatile__("mfence" ::: "memory")
#define rmb() __asm__ __volatile__("lfence" ::: "memory")
#define wmb() __asm__ __volatile__("sfence" ::: "memory")
#define smp_mb() mb()
#define smp_rmb() barrier()
#define smp_wmb() barrier()
#define dma_rmb() barrier()
#define dma_wmb() barrier()
#define smp_mb__before_atomic() barrier()
#define smp_mb__after_atomic() barrier()
#define cpu_relax() __asm__ __volatile__("pause" ::: "memory")
#define READ_ONCE(x) (*(const volatile __typeof__(x) *)&(x))
#define WRITE_ONCE(x, v) (*(volatile __typeof__(x) *)&(x) = (v))
#define ACCESS_ONCE(x) READ_ONCE(x)

#define offsetof(T, m) __builtin_offsetof(T, m)
#define container_of(ptr, type, member) \
	((type *)((char *)(ptr) - offsetof(type, member)))
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define sizeof_field(T, m) sizeof(((T *)0)->m)
#define BUILD_BUG_ON(c) _Static_assert(!(c), "BUILD_BUG_ON")
#define BUILD_BUG_ON_ZERO(e) 0
#define __stringify_1(x) #x
#define __stringify(x) __stringify_1(x)
#define typecheck(t, x) 1

#define min(a, b) ({ __typeof__(a) _a = (a); __typeof__(b) _b = (b); _a < _b ? _a : _b; })
#define max(a, b) ({ __typeof__(a) _a = (a); __typeof__(b) _b = (b); _a > _b ? _a : _b; })
#define min3(a, b, c) min(min(a, b), c)
#define max3(a, b, c) max(max(a, b), c)
#define min_t(T, a, b) ({ T _a = (a); T _b = (b); _a < _b ? _a : _b; })
#define max_t(T, a, b) ({ T _a = (a); T _b = (b); _a > _b ? _a : _b; })
#define clamp(v, lo, hi) min(max(v, lo), hi)
#define clamp_t(T, v, lo, hi) min_t(T, max_t(T, v, lo), hi)
#define clamp_val(v, lo, hi) clamp_t(__typeof__(v), v, lo, hi)
#define swap(a, b) do { __typeof__(a) _t = (a); (a) = (b); (b) = _t; } while (0)
#define abs(x) ({ __typeof__(x) _x = (x); _x < 0 ? -_x : _x; })
#define DIV_ROUND_UP(n, d) (((n) + (d) - 1) / (d))
#define DIV_ROUND_CLOSEST(x, d) (((x) + ((d) / 2)) / (d))
#define roundup(x, y) ((((x) + ((y) - 1)) / (y)) * (y))
#define rounddown(x, y) ((x) - ((x) % (y)))
#define ALIGN(x, a) __ALIGN_KERNEL((x), (a))
#define ALIGN_DOWN(x, a) ((x) & ~((__typeof__(x))(a) - 1))
#define PTR_ALIGN(p, a) ((__typeof__(p))ALIGN((unsigned long)(p), (a)))
#define IS_ALIGNED(x, a) (((x) & ((__typeof__(x))(a) - 1)) == 0)
#define is_power_of_2(n) ((n) != 0 && (((n) & ((n) - 1)) == 0))
#define upper_32_bits(n) ((u32)(((n) >> 16) >> 16))
#define lower_32_bits(n) ((u32)((n) & 0xffffffff))
#define BIT(n) (1UL << (n))
#define BIT_ULL(n) (1ULL << (n))
#define BIT_MASK(n) (1UL << ((n) % BITS_PER_LONG))
#define BIT_WORD(n) ((n) / BITS_PER_LONG)
#define GENMASK(h, l) (((~0UL) - (1UL << (l)) + 1) & (~0UL >> (BITS_PER_LONG - 1 - (h))))
#define GENMASK_ULL(h, l) (((~0ULL) - (1ULL << (l)) + 1) & (~0ULL >> (63 - (h))))
#define IS_ENABLED(x) 0
#define PAGE_SIZE 4096UL
#define PAGE_SHIFT 12
#define SMP_CACHE_BYTES 64
#define L1_CACHE_BYTES 64
#define ____cacheline_aligned __attribute__((aligned(SMP_CACHE_BYTES)))
#define ____cacheline_aligned_in_smp ____cacheline_aligned
#define __cacheline_aligned ____cacheline_aligned

static inline int ilog2(unsigned long v) { return 63 - __builtin_clzl(v); }
static inline int fls(unsigned int x) { return x ? 32 - __builtin_clz(x) : 0; }
static inline unsigned long __ffs(unsigned long x) { return __builtin_ctzl(x); }
static inline int ffs(int x) { return __builtin_ffs(x); }
static inline unsigned int hweight32(u32 w) { return __builtin_popcount(w); }
static inline unsigned long hweight64(u64 w) { return __builtin_popcountll(w); }
static inline u32 bitrev32(u32 x)
{
	x = ((x >> 1) & 0x55555555) | ((x & 0x55555555) << 1);
	x = ((x >> 2) & 0x33333333) | ((x & 0x33333333) << 2);
	x = ((x >> 4) & 0x0F0F0F0F) | ((x & 0x0F0F0F0F) << 4);
	return __builtin_bswap32(x);
}
#define roundup_pow_of_two(n) (1UL << (64 - __builtin_clzl((n) - 1)))
#define order_base_2(n) ((n) > 1 ? ilog2((n) - 1) + 1 : 0)

/* ----- порядок байтов (x86 — little-endian) ----- */
#define cpu_to_le16(x) ((__le16)(u16)(x))
#define cpu_to_le32(x) ((__le32)(u32)(x))
#define cpu_to_le64(x) ((__le64)(u64)(x))
#define le16_to_cpu(x) ((u16)(__le16)(x))
#define le32_to_cpu(x) ((u32)(__le32)(x))
#define le64_to_cpu(x) ((u64)(__le64)(x))
#define cpu_to_be16(x) ((__be16)__builtin_bswap16(x))
#define cpu_to_be32(x) ((__be32)__builtin_bswap32(x))
#define cpu_to_be64(x) ((__be64)__builtin_bswap64(x))
#define be16_to_cpu(x) __builtin_bswap16((u16)(x))
#define be32_to_cpu(x) __builtin_bswap32((u32)(x))
#define be64_to_cpu(x) __builtin_bswap64((u64)(x))
#define htons(x) cpu_to_be16(x)
#define ntohs(x) be16_to_cpu(x)
#define htonl(x) cpu_to_be32(x)
#define ntohl(x) be32_to_cpu(x)
#define le16_to_cpus(p) do {} while (0)
#define le32_to_cpus(p) do {} while (0)
#define cpu_to_le32s(p) do {} while (0)
#define le16_add_cpu(p, v) (*(p) += (v))
#define le32_add_cpu(p, v) (*(p) += (v))
static inline u16 get_unaligned_le16(const void *p) { const u8 *b = p; return b[0] | b[1] << 8; }
static inline u32 get_unaligned_le32(const void *p) { const u8 *b = p; return b[0] | b[1] << 8 | b[2] << 16 | (u32)b[3] << 24; }
static inline u16 get_unaligned_be16(const void *p) { const u8 *b = p; return b[0] << 8 | b[1]; }
static inline u32 get_unaligned_be32(const void *p) { const u8 *b = p; return (u32)b[0] << 24 | b[1] << 16 | b[2] << 8 | b[3]; }
static inline void put_unaligned_le16(u16 v, void *p) { u8 *b = p; b[0] = v; b[1] = v >> 8; }
static inline void put_unaligned_le32(u32 v, void *p) { u8 *b = p; b[0] = v; b[1] = v >> 8; b[2] = v >> 16; b[3] = v >> 24; }
#define swab16(x) __builtin_bswap16(x)
#define swab32(x) __builtin_bswap32(x)
#define swab64(x) __builtin_bswap64(x)
#define get_unaligned(p) (*(p))
#define put_unaligned(v, p) (*(p) = (v))

/* ----- ошибки ----- */
#define EPERM 1
#define ENOENT 2
#define EINTR 4
#define EIO 5
#define ENXIO 6
#define E2BIG 7
#define EAGAIN 11
#define ENOMEM 12
#define EFAULT 14
#define EBUSY 16
#define EEXIST 17
#define ENODEV 19
#define EINVAL 22
#define ENOSPC 28
#define ERANGE 34
#define ENOSYS 38
#define ENODATA 61
#define ETIME 62
#define EPROTO 71
#define EBADMSG 74
#define EOVERFLOW 75
#define EMSGSIZE 90
#define EOPNOTSUPP 95
#define ENOTSUPP 524
#define EADDRNOTAVAIL 99
#define ENETDOWN 100
#define ENOBUFS 105
#define ETIMEDOUT 110
#define EALREADY 114
#define EINPROGRESS 115
#define ECANCELED 125
#define MAX_ERRNO 4095
#define IS_ERR_VALUE(x) ((unsigned long)(void *)(x) >= (unsigned long)-MAX_ERRNO)
static inline void *ERR_PTR(long e) { return (void *)e; }
static inline long PTR_ERR(const void *p) { return (long)p; }
static inline bool IS_ERR(const void *p) { return IS_ERR_VALUE(p); }
static inline bool IS_ERR_OR_NULL(const void *p) { return !p || IS_ERR_VALUE(p); }
#define ERR_CAST(p) ((void *)(p))

/* ----- печать ----- */
#define KERN_SOH "\001"
#define KERN_EMERG KERN_SOH "0"
#define KERN_ALERT KERN_SOH "1"
#define KERN_CRIT KERN_SOH "2"
#define KERN_ERR KERN_SOH "3"
#define KERN_WARNING KERN_SOH "4"
#define KERN_NOTICE KERN_SOH "5"
#define KERN_INFO KERN_SOH "6"
#define KERN_DEBUG KERN_SOH "7"
#define KERN_CONT KERN_SOH "c"
#ifndef pr_fmt
#define pr_fmt(fmt) fmt
#endif
__printf(1, 2) int printk(const char *fmt, ...);
__printf(3, 4) int snprintf(char *buf, size_t size, const char *fmt, ...);
__printf(2, 3) int sprintf(char *buf, const char *fmt, ...);
__printf(3, 4) int scnprintf(char *buf, size_t size, const char *fmt, ...);
int vsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
int vscnprintf(char *buf, size_t size, const char *fmt, va_list ap);
static inline __printf(1, 2) int no_printk(const char *fmt, ...) { return 0; }
#define pr_emerg(fmt, ...) printk(KERN_EMERG pr_fmt(fmt), ##__VA_ARGS__)
#define pr_alert(fmt, ...) printk(KERN_ALERT pr_fmt(fmt), ##__VA_ARGS__)
#define pr_crit(fmt, ...) printk(KERN_CRIT pr_fmt(fmt), ##__VA_ARGS__)
#define pr_err(fmt, ...) printk(KERN_ERR pr_fmt(fmt), ##__VA_ARGS__)
#define pr_warn(fmt, ...) printk(KERN_WARNING pr_fmt(fmt), ##__VA_ARGS__)
#define pr_warning pr_warn
#define pr_notice(fmt, ...) printk(KERN_NOTICE pr_fmt(fmt), ##__VA_ARGS__)
#define pr_info(fmt, ...) printk(KERN_INFO pr_fmt(fmt), ##__VA_ARGS__)
#define pr_cont(fmt, ...) printk(KERN_CONT fmt, ##__VA_ARGS__)
#define pr_debug(fmt, ...) no_printk(pr_fmt(fmt), ##__VA_ARGS__)
#define pr_devel pr_debug
#define pr_err_once pr_err
#define pr_warn_once pr_warn
#define pr_info_once pr_info
#define pr_warn_ratelimited pr_warn
#define pr_err_ratelimited pr_err
#define printk_ratelimit() 1
#define net_ratelimit() 1
#define DUMP_PREFIX_NONE 0
#define DUMP_PREFIX_ADDRESS 1
#define DUMP_PREFIX_OFFSET 2
void print_hex_dump(const char *level, const char *prefix, int type, int rowsize,
		    int groupsize, const void *buf, size_t len, bool ascii);
#define print_hex_dump_debug(...) do {} while (0)
#define print_hex_dump_bytes(p, t, b, l) print_hex_dump(KERN_DEBUG, p, t, 16, 1, b, l, true)

void lde_bug(const char *file, int line) __noreturn;
#define BUG() lde_bug(__FILE__, __LINE__)
#define BUG_ON(c) do { if (unlikely(c)) BUG(); } while (0)
#define WARN_ON(c) ({ int _c = !!(c); if (unlikely(_c)) printk(KERN_WARNING "WARNING at %s:%d\n", __FILE__, __LINE__); unlikely(_c); })
#define WARN_ON_ONCE(c) WARN_ON(c)
#define WARN(c, fmt, ...) ({ int _c = !!(c); if (unlikely(_c)) printk(KERN_WARNING fmt, ##__VA_ARGS__); unlikely(_c); })
#define WARN_ONCE WARN
#define might_sleep() do {} while (0)

/* ----- модули ----- */
struct module;
#define THIS_MODULE ((struct module *)0)
#define MODULE_LICENSE(x)
#define MODULE_AUTHOR(x)
#define MODULE_DESCRIPTION(x)
#define MODULE_VERSION(x)
#define MODULE_FIRMWARE(x)
#define MODULE_ALIAS(x)
/* таблица устройств модуля: по ней строится список PCI ID пакета */
#define MODULE_DEVICE_TABLE(type, name) \
	extern __typeof__(name) __mod_##type##__lde_device_table __attribute__((alias(#name)));
#define MODULE_PARM_DESC(a, b)
#define MODULE_INFO(a, b)
#define MODULE_IMPORT_NS(x)
#define module_param(name, type, perm)
#define module_param_named(n, v, t, p)
#define module_param_array(name, type, nump, perm)
#define EXPORT_SYMBOL(x)
#define EXPORT_SYMBOL_GPL(x)
#define EXPORT_SYMBOL_NS_GPL(x, ns)
typedef int (*initcall_t)(void);
/* имя функции инициализации модуля задаёт сборка: -DLDE_MODULE=<имя> */
#define __lde_cat(a, b) a##b
#define __lde_initcall(m) __lde_cat(lde_initcall_, m)
#define __lde_exitcall(m) __lde_cat(lde_exitcall_, m)
/* версия двоичного интерфейса LDE: модуль другой версии не загружается */
#define LDE_ABI 1
#define module_init(fn) \
	const unsigned int __lde_module_abi __attribute__((weak, used)) = LDE_ABI; \
	int __lde_initcall(LDE_MODULE)(void) { return fn(); }
#define module_exit(fn) void __lde_exitcall(LDE_MODULE)(void) { fn(); }
#define try_module_get(m) 1
#define module_put(m) do {} while (0)

/* ----- строки и память ----- */
void *memset(void *s, int c, size_t n);
void *memcpy(void *d, const void *s, size_t n);
void *memmove(void *d, const void *s, size_t n);
int memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);
void *memchr(const void *s, int c, size_t n);
size_t strnlen(const char *s, size_t n);
int strcmp(const char *a, const char *b);
int strncmp(const char *a, const char *b, size_t n);
char *strchr(const char *s, int c);
char *strcpy(char *d, const char *s);
char *strncpy(char *d, const char *s, size_t n);
size_t strlcpy(char *d, const char *s, size_t n);
ssize_t lde_strscpy(char *d, const char *s, size_t n);
#define strscpy(d, s, ...) lde_strscpy(d, s, __lde_strscpy_n(d, ##__VA_ARGS__, sizeof(d)))
#define __lde_strscpy_n(d, n, ...) (n)
char *kstrdup(const char *s, gfp_t gfp);
void *kmemdup(const void *s, size_t n, gfp_t gfp);

#define GFP_KERNEL 0x1u
#define GFP_ATOMIC 0x2u
#define GFP_NOWAIT 0x2u
#define GFP_DMA 0x4u
#define GFP_DMA32 0x8u
#define __GFP_ZERO 0x100u
#define __GFP_NOWARN 0x200u
#define __GFP_COMP 0x400u
#define GFP_NOIO GFP_KERNEL
void *kmalloc(size_t size, gfp_t gfp);
void kfree(const void *p);
size_t ksize(const void *p);
#define kfree_sensitive kfree
#define kvfree kfree
#define vfree kfree
static inline void *kzalloc(size_t size, gfp_t gfp) { return kmalloc(size, gfp | __GFP_ZERO); }
static inline void *kmalloc_array(size_t n, size_t size, gfp_t gfp) { return kmalloc(n * size, gfp); }
static inline void *kcalloc(size_t n, size_t size, gfp_t gfp) { return kzalloc(n * size, gfp); }
#define kvmalloc kmalloc
#define kvzalloc kzalloc
#define kvcalloc kcalloc
#define vmalloc(s) kmalloc(s, GFP_KERNEL)
#define vzalloc(s) kzalloc(s, GFP_KERNEL)
void *krealloc(const void *p, size_t size, gfp_t gfp);
#define struct_size(p, member, n) (sizeof(*(p)) + sizeof(*(p)->member) * (n))
#define array_size(a, b) ((a) * (b))
#define size_add(a, b) ((a) + (b))

/* ----- время ----- */
#define HZ 1000
unsigned long lde_jiffies(void);
#define jiffies (lde_jiffies())
#define jiffies_64 jiffies
#define time_after(a, b) ((long)((b) - (a)) < 0)
#define time_before(a, b) time_after(b, a)
#define time_after_eq(a, b) ((long)((a) - (b)) >= 0)
#define time_before_eq(a, b) time_after_eq(b, a)
#define time_is_before_jiffies(a) time_after(jiffies, a)
#define time_is_after_jiffies(a) time_before(jiffies, a)
#define time_in_range(a, b, c) (time_after_eq(a, b) && time_before_eq(a, c))
static inline unsigned long msecs_to_jiffies(unsigned int m) { return m; }
static inline unsigned long usecs_to_jiffies(unsigned int u) { return (u + 999) / 1000; }
static inline unsigned int jiffies_to_msecs(unsigned long j) { return j; }
static inline unsigned int jiffies_to_usecs(unsigned long j) { return j * 1000; }
static inline unsigned long round_jiffies(unsigned long j) { return j; }
static inline unsigned long round_jiffies_relative(unsigned long j) { return j; }
static inline unsigned long round_jiffies_up(unsigned long j) { return j; }
#define udelay(us) qx_delay_us(us)
#define ndelay(ns) qx_delay_us(((ns) + 999) / 1000)
#define mdelay(ms) qx_delay_us((u64)(ms) * 1000)
#define msleep(ms) qx_delay_us((u64)(ms) * 1000)
#define usleep_range(a, b) qx_delay_us(a)
#define fsleep(us) qx_delay_us(us)
#define ssleep(s) qx_delay_us((u64)(s) * 1000000)
static inline unsigned long msleep_interruptible(unsigned int ms) { msleep(ms); return 0; }
typedef s64 ktime_t;
static inline ktime_t ktime_get(void) { return (ktime_t)qx_uptime_us() * 1000; }
#define ktime_get_boottime ktime_get
#define ktime_get_real ktime_get
static inline s64 ktime_to_us(ktime_t t) { return t / 1000; }
static inline s64 ktime_to_ms(ktime_t t) { return t / 1000000; }
static inline s64 ktime_to_ns(ktime_t t) { return t; }
static inline s64 ktime_us_delta(ktime_t a, ktime_t b) { return (a - b) / 1000; }
static inline u64 ktime_get_ns(void) { return qx_uptime_us() * 1000; }
#define ktime_get_boottime_ns ktime_get_ns
static inline u64 local_clock(void) { return ktime_get_ns(); }
#define ktime_add_us(t, us) ((t) + (s64)(us) * 1000)
#define ktime_add_ms(t, ms) ((t) + (s64)(ms) * 1000000)
#define ktime_after(a, b) ((a) > (b))
#define ktime_before(a, b) ((a) < (b))
#define ktime_compare(a, b) ((a) < (b) ? -1 : (a) > (b))
#define NSEC_PER_USEC 1000L
#define NSEC_PER_MSEC 1000000L
#define USEC_PER_MSEC 1000L
#define USEC_PER_SEC 1000000L
#define MSEC_PER_SEC 1000L
#define NSEC_PER_SEC 1000000000L

/* ----- блокировки (один поток: пустые операции) ----- */
typedef struct { int unused; } spinlock_t;
typedef struct { int unused; } raw_spinlock_t;
typedef struct { int unused; } rwlock_t;
struct mutex { int locked; };
#define DEFINE_SPINLOCK(x) spinlock_t x
#define DEFINE_MUTEX(x) struct mutex x
#define spin_lock_init(l) ((void)(l))
#define spin_lock(l) ((void)(l))
#define spin_unlock(l) ((void)(l))
#define spin_lock_bh(l) ((void)(l))
#define spin_unlock_bh(l) ((void)(l))
#define spin_lock_irq(l) ((void)(l))
#define spin_unlock_irq(l) ((void)(l))
#define spin_lock_irqsave(l, f) ((void)(l), (f) = 0)
#define spin_unlock_irqrestore(l, f) ((void)(l), (void)(f))
#define spin_trylock(l) ((void)(l), 1)
#define raw_spin_lock_init spin_lock_init
#define raw_spin_lock_irqsave spin_lock_irqsave
#define raw_spin_unlock_irqrestore spin_unlock_irqrestore
#define lockdep_assert_held(l) do {} while (0)
#define mutex_init(m) ((m)->locked = 0)
#define mutex_lock(m) ((m)->locked = 1)
#define mutex_unlock(m) ((m)->locked = 0)
#define mutex_trylock(m) ((m)->locked ? 0 : ((m)->locked = 1))
#define mutex_is_locked(m) ((m)->locked)
#define mutex_destroy(m) do {} while (0)
#define local_irq_save(f) ((f) = 0)
#define local_irq_restore(f) ((void)(f))
#define local_irq_disable() do {} while (0)
#define local_irq_enable() do {} while (0)
#define local_bh_disable() do {} while (0)
#define local_bh_enable() do {} while (0)
#define preempt_disable() do {} while (0)
#define preempt_enable() do {} while (0)
#define rcu_read_lock() do {} while (0)
#define rcu_read_unlock() do {} while (0)
#define rcu_read_lock_bh() do {} while (0)
#define rcu_read_unlock_bh() do {} while (0)
#define synchronize_rcu() do {} while (0)
#define synchronize_net() do {} while (0)
#define rcu_dereference(p) (p)
#define rcu_dereference_protected(p, c) (p)
#define rcu_access_pointer(p) (p)
#define rcu_assign_pointer(p, v) ((p) = (v))
#define RCU_INIT_POINTER(p, v) ((p) = (v))
#define kfree_rcu(p, f) kfree(p)
#define rtnl_lock() do {} while (0)
#define rtnl_unlock() do {} while (0)
#define ASSERT_RTNL() do {} while (0)
#define in_interrupt() 0
#define in_irq() 0
#define in_atomic() 0
#define irqs_disabled() 0

/* ----- атомарные операции ----- */
#define ATOMIC_INIT(i) { (i) }
#define atomic_read(v) READ_ONCE((v)->counter)
#define atomic_set(v, i) WRITE_ONCE((v)->counter, (i))
#define atomic_inc(v) __atomic_add_fetch(&(v)->counter, 1, __ATOMIC_SEQ_CST)
#define atomic_dec(v) __atomic_sub_fetch(&(v)->counter, 1, __ATOMIC_SEQ_CST)
#define atomic_add(i, v) __atomic_add_fetch(&(v)->counter, (i), __ATOMIC_SEQ_CST)
#define atomic_sub(i, v) __atomic_sub_fetch(&(v)->counter, (i), __ATOMIC_SEQ_CST)
#define atomic_inc_return(v) __atomic_add_fetch(&(v)->counter, 1, __ATOMIC_SEQ_CST)
#define atomic_dec_return(v) __atomic_sub_fetch(&(v)->counter, 1, __ATOMIC_SEQ_CST)
#define atomic_dec_and_test(v) (atomic_dec_return(v) == 0)
#define atomic_inc_and_test(v) (atomic_inc_return(v) == 0)
#define atomic_xchg(v, n) __atomic_exchange_n(&(v)->counter, (n), __ATOMIC_SEQ_CST)
#define atomic_cmpxchg(v, o, n) ({ int _o = (o); __atomic_compare_exchange_n(&(v)->counter, &_o, (n), 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); _o; })

/* ----- биты ----- */
static inline void set_bit(long nr, volatile unsigned long *a) { a[BIT_WORD(nr)] |= BIT_MASK(nr); }
static inline void clear_bit(long nr, volatile unsigned long *a) { a[BIT_WORD(nr)] &= ~BIT_MASK(nr); }
static inline void change_bit(long nr, volatile unsigned long *a) { a[BIT_WORD(nr)] ^= BIT_MASK(nr); }
static inline bool test_bit(long nr, const volatile unsigned long *a) { return (a[BIT_WORD(nr)] >> (nr % BITS_PER_LONG)) & 1; }
static inline bool test_and_set_bit(long nr, volatile unsigned long *a) { bool o = test_bit(nr, a); set_bit(nr, a); return o; }
static inline bool test_and_clear_bit(long nr, volatile unsigned long *a) { bool o = test_bit(nr, a); clear_bit(nr, a); return o; }
#define __set_bit set_bit
#define __clear_bit clear_bit
#define __test_and_set_bit test_and_set_bit
#define __test_and_clear_bit test_and_clear_bit
#define clear_bit_unlock clear_bit
#define test_and_set_bit_lock test_and_set_bit
static inline void bitmap_zero(unsigned long *d, unsigned int n) { memset(d, 0, BITS_TO_LONGS(n) * sizeof(long)); }
static inline void bitmap_fill(unsigned long *d, unsigned int n) { memset(d, 0xff, BITS_TO_LONGS(n) * sizeof(long)); }
static inline void bitmap_copy(unsigned long *d, const unsigned long *s, unsigned int n) { memcpy(d, s, BITS_TO_LONGS(n) * sizeof(long)); }
static inline bool bitmap_empty(const unsigned long *s, unsigned int n)
{
	for (unsigned int i = 0; i < n; i++)
		if (test_bit(i, s))
			return false;
	return true;
}
static inline void bitmap_or(unsigned long *d, const unsigned long *a, const unsigned long *b, unsigned int n)
{
	for (unsigned int i = 0; i < BITS_TO_LONGS(n); i++)
		d[i] = a[i] | b[i];
}
static inline bool bitmap_and(unsigned long *d, const unsigned long *a, const unsigned long *b, unsigned int n)
{
	unsigned long r = 0;
	for (unsigned int i = 0; i < BITS_TO_LONGS(n); i++)
		r |= (d[i] = a[i] & b[i]);
	return r != 0;
}
static inline bool bitmap_equal(const unsigned long *a, const unsigned long *b, unsigned int n)
{
	for (unsigned int i = 0; i < n; i++)
		if (test_bit(i, a) != test_bit(i, b))
			return false;
	return true;
}
static inline unsigned long find_first_bit(const unsigned long *a, unsigned long n)
{
	for (unsigned long i = 0; i < n; i++)
		if (test_bit(i, a))
			return i;
	return n;
}
static inline unsigned long find_next_bit(const unsigned long *a, unsigned long n, unsigned long o)
{
	for (unsigned long i = o; i < n; i++)
		if (test_bit(i, a))
			return i;
	return n;
}
#define for_each_set_bit(b, a, n) \
	for ((b) = find_first_bit(a, n); (b) < (n); (b) = find_next_bit(a, n, (b) + 1))

/* ----- списки ----- */
#define LIST_HEAD_INIT(n) { &(n), &(n) }
#define LIST_HEAD(n) struct list_head n = LIST_HEAD_INIT(n)
static inline void INIT_LIST_HEAD(struct list_head *l) { l->next = l; l->prev = l; }
static inline void __list_add(struct list_head *n, struct list_head *p, struct list_head *x)
{
	x->prev = n; n->next = x; n->prev = p; p->next = n;
}
static inline void list_add(struct list_head *n, struct list_head *h) { __list_add(n, h, h->next); }
static inline void list_add_tail(struct list_head *n, struct list_head *h) { __list_add(n, h->prev, h); }
static inline void list_del(struct list_head *e)
{
	e->next->prev = e->prev; e->prev->next = e->next; e->next = e->prev = 0;
}
static inline void list_del_init(struct list_head *e) { list_del(e); INIT_LIST_HEAD(e); }
static inline int list_empty(const struct list_head *h) { return h->next == h; }
#define list_entry(p, T, m) container_of(p, T, m)
#define list_first_entry(p, T, m) list_entry((p)->next, T, m)
#define list_first_entry_or_null(p, T, m) (list_empty(p) ? NULL : list_first_entry(p, T, m))
#define list_next_entry(p, m) list_entry((p)->m.next, __typeof__(*(p)), m)
#define list_for_each(p, h) for (p = (h)->next; p != (h); p = p->next)
#define list_for_each_entry(p, h, m) \
	for (p = list_entry((h)->next, __typeof__(*p), m); &p->m != (h); p = list_next_entry(p, m))
#define list_for_each_entry_safe(p, n, h, m) \
	for (p = list_entry((h)->next, __typeof__(*p), m), n = list_next_entry(p, m); \
	     &p->m != (h); p = n, n = list_next_entry(n, m))

/* ----- отложенная работа и таймеры ----- */
struct work_struct;
typedef void (*work_func_t)(struct work_struct *);
struct work_struct {
	work_func_t func;
	struct list_head entry;
	int pending;
};
struct timer_list {
	void (*function)(struct timer_list *);
	unsigned long expires;
	int pending;
	struct list_head entry;
};
struct delayed_work {
	struct work_struct work;
	struct timer_list timer;
};
struct workqueue_struct;
#define system_wq ((struct workqueue_struct *)0)
#define system_long_wq ((struct workqueue_struct *)0)
#define system_power_efficient_wq ((struct workqueue_struct *)0)
#define system_unbound_wq ((struct workqueue_struct *)0)
#define system_highpri_wq ((struct workqueue_struct *)0)
#define system_freezable_wq ((struct workqueue_struct *)0)
void lde_init_work(struct work_struct *w, work_func_t f);
void lde_init_delayed_work(struct delayed_work *w, work_func_t f);
#define INIT_WORK(w, f) lde_init_work(w, f)
#define INIT_DELAYED_WORK(w, f) lde_init_delayed_work(w, f)
#define INIT_DEFERRABLE_WORK INIT_DELAYED_WORK
bool queue_work(struct workqueue_struct *q, struct work_struct *w);
bool queue_delayed_work(struct workqueue_struct *q, struct delayed_work *w, unsigned long delay);
bool mod_delayed_work(struct workqueue_struct *q, struct delayed_work *w, unsigned long delay);
bool cancel_work_sync(struct work_struct *w);
bool cancel_delayed_work(struct delayed_work *w);
bool cancel_delayed_work_sync(struct delayed_work *w);
#define cancel_work cancel_work_sync
#define flush_work(w) ((void)(w), true)
#define flush_delayed_work(w) ((void)(w), true)
#define flush_workqueue(q) do {} while (0)
#define drain_workqueue(q) do {} while (0)
#define schedule_work(w) queue_work(system_wq, w)
#define schedule_delayed_work(w, d) queue_delayed_work(system_wq, w, d)
#define delayed_work_pending(w) ((w)->timer.pending || (w)->work.pending)
#define work_pending(w) ((w)->pending)
#define to_delayed_work(w) container_of(w, struct delayed_work, work)
struct workqueue_struct *alloc_workqueue(const char *fmt, unsigned int flags, int max, ...);
#define alloc_ordered_workqueue(fmt, flags, ...) alloc_workqueue(fmt, flags, 1, ##__VA_ARGS__)
#define create_singlethread_workqueue(n) alloc_workqueue(n, 0, 1)
#define destroy_workqueue(q) do {} while (0)
#define WQ_UNBOUND 0
#define WQ_HIGHPRI 0
#define WQ_MEM_RECLAIM 0
#define WQ_FREEZABLE 0
void timer_setup(struct timer_list *t, void (*fn)(struct timer_list *), unsigned int flags);
int mod_timer(struct timer_list *t, unsigned long expires);
#define add_timer(t) mod_timer(t, (t)->expires)
int del_timer(struct timer_list *t);
#define del_timer_sync del_timer
#define timer_delete del_timer
#define timer_delete_sync del_timer
#define timer_shutdown_sync del_timer
#define timer_pending(t) ((t)->pending)
#define from_timer(var, t, field) container_of(t, __typeof__(*var), field)

/* ----- ожидание ----- */
struct completion { unsigned int done; };
#define init_completion(c) ((c)->done = 0)
#define reinit_completion(c) ((c)->done = 0)
#define complete(c) ((c)->done++)
#define complete_all(c) ((c)->done = ~0u >> 1)
#define DECLARE_COMPLETION_ONSTACK(c) struct completion c = { 0 }
unsigned long lde_wait_for(unsigned int *done, unsigned long timeout);
#define wait_for_completion_timeout(c, t) lde_wait_for(&(c)->done, t)
#define wait_for_completion(c) ((void)lde_wait_for(&(c)->done, ~0UL >> 1))
typedef struct { int unused; } wait_queue_head_t;
#define init_waitqueue_head(w) ((void)(w))
#define wake_up(w) ((void)(w))
#define wake_up_all(w) ((void)(w))
#define wake_up_interruptible(w) ((void)(w))
#define schedule() do {} while (0)
#define TASK_RUNNING 0
#define TASK_INTERRUPTIBLE 1
#define TASK_UNINTERRUPTIBLE 2
#define set_current_state(s) do {} while (0)
#define __set_current_state(s) do {} while (0)
static inline long schedule_timeout(long j) { msleep(j); return 0; }
#define schedule_timeout_uninterruptible schedule_timeout
#define schedule_timeout_interruptible schedule_timeout
#define schedule_timeout_idle schedule_timeout
#define cond_resched() do {} while (0)
#define signal_pending(t) 0
#define current ((void *)0)

/* ----- crc ----- */
u32 crc32_le(u32 crc, const unsigned char *p, size_t len);
u32 crc32_be(u32 crc, const unsigned char *p, size_t len);
#define crc32(seed, data, len) crc32_le(seed, data, len)
#define ether_crc(length, data) bitrev32(crc32_le(~0, data, length))
#define ether_crc_le(length, data) crc32_le(~0, data, length)

/* ----- разное ----- */
#define get_random_u32() lde_random_u32()
u32 lde_random_u32(void);
#define get_random_bytes(p, n) lde_random_bytes(p, n)
void lde_random_bytes(void *p, size_t n);
#define prefetch(p) ((void)(p))
#define prefetchw(p) ((void)(p))
#define num_online_cpus() 1
#define num_possible_cpus() 1
#define smp_processor_id() 0
#define raw_smp_processor_id() 0
#define dump_stack() do {} while (0)
#define copy_from_user(d, s, n) (memcpy(d, s, n), 0)
#define copy_to_user(d, s, n) (memcpy(d, s, n), 0)
static inline int kstrtoint(const char *s, unsigned int base, int *res) { (void)s; (void)base; *res = 0; return -EINVAL; }
#define tolower(c) ((c) >= 'A' && (c) <= 'Z' ? (c) + 32 : (c))
#define toupper(c) ((c) >= 'a' && (c) <= 'z' ? (c) - 32 : (c))
#define isdigit(c) ((c) >= '0' && (c) <= '9')
#define isxdigit(c) (isdigit(c) || (tolower(c) >= 'a' && tolower(c) <= 'f'))
#define isspace(c) ((c) == ' ' || ((c) >= '\t' && (c) <= '\r'))
static inline int hex_to_bin(unsigned char c)
{
	if (isdigit(c)) return c - '0';
	c = tolower(c);
	if (c >= 'a' && c <= 'f') return c - 'a' + 10;
	return -1;
}

#endif
