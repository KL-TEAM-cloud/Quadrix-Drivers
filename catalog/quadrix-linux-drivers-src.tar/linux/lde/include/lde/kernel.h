/* SPDX-License-Identifier: GPL-2.0 */
/* Quadrix LDE: общий заголовок, на который указывают заголовки linux/ и asm/. */
#ifndef _LDE_KERNEL_H
#define _LDE_KERNEL_H
#include <lde/base.h>
#include <lde/pci.h>
#include <lde/net.h>
#endif
