/* SPDX-License-Identifier: GPL-2.0 */
/* Quadrix LDE: устройства, PCI, ввод-вывод, DMA, прерывания. */
#ifndef _LDE_PCI_H
#define _LDE_PCI_H

#include <lde/base.h>

struct device;

/* ----- устройства ----- */
struct dev_pm_ops {
	int (*suspend)(struct device *);
	int (*resume)(struct device *);
	int (*freeze)(struct device *);
	int (*thaw)(struct device *);
	int (*poweroff)(struct device *);
	int (*restore)(struct device *);
	int (*runtime_suspend)(struct device *);
	int (*runtime_resume)(struct device *);
};
#define SIMPLE_DEV_PM_OPS(name, s, r) \
	const struct dev_pm_ops __maybe_unused name = { .suspend = s, .resume = r }
#define DEFINE_SIMPLE_DEV_PM_OPS SIMPLE_DEV_PM_OPS
#define pm_sleep_ptr(p) (p)
#define pm_ptr(p) (p)
#define SET_SYSTEM_SLEEP_PM_OPS(s, r) .suspend = s, .resume = r,
#define SET_RUNTIME_PM_OPS(s, r, i)
#define __maybe_unused_pm __maybe_unused

struct device_driver {
	const char *name;
	const struct dev_pm_ops *pm;
	struct module *owner;
};

struct device {
	struct device *parent;
	const char *init_name;
	void *driver_data;
	struct device_driver *driver;
	u64 *dma_mask;
	u64 coherent_dma_mask;
};

static inline void *dev_get_drvdata(const struct device *d) { return d->driver_data; }
static inline void dev_set_drvdata(struct device *d, void *p) { d->driver_data = p; }
static inline const char *dev_name(const struct device *d) { return d->init_name ? d->init_name : "lde"; }
#define dev_printk(lvl, dev, fmt, ...) printk(lvl "%s: " fmt, dev_name(dev), ##__VA_ARGS__)
#define dev_err(dev, fmt, ...) dev_printk(KERN_ERR, dev, fmt, ##__VA_ARGS__)
#define dev_warn(dev, fmt, ...) dev_printk(KERN_WARNING, dev, fmt, ##__VA_ARGS__)
#define dev_notice(dev, fmt, ...) dev_printk(KERN_NOTICE, dev, fmt, ##__VA_ARGS__)
#define dev_info(dev, fmt, ...) dev_printk(KERN_INFO, dev, fmt, ##__VA_ARGS__)
#define dev_dbg(dev, fmt, ...) no_printk(fmt, ##__VA_ARGS__)
#define dev_err_once dev_err
#define dev_warn_once dev_warn
#define dev_info_once dev_info
#define dev_err_ratelimited dev_err
#define dev_warn_ratelimited dev_warn
#define dev_dbg_ratelimited dev_dbg
#define dev_err_probe(dev, err, fmt, ...) ({ dev_err(dev, fmt, ##__VA_ARGS__); (err); })
#define get_device(d) (d)
#define put_device(d) do {} while (0)
#define device_set_wakeup_enable(d, e) 0
#define device_set_wakeup_capable(d, e) do {} while (0)
#define device_can_wakeup(d) 0
#define device_may_wakeup(d) 0
#define device_init_wakeup(d, e) 0

/* ----- ресурсы ----- */
#define IORESOURCE_IO 0x00000100
#define IORESOURCE_MEM 0x00000200
#define IORESOURCE_MEM_64 0x00100000
struct resource {
	resource_size_t start, end;
	unsigned long flags;
	const char *name;
};
static inline resource_size_t resource_size(const struct resource *r) { return r->end - r->start + 1; }

/* ----- PCI ----- */
#define PCI_ANY_ID (~0)
#include <linux/pci_ids.h>

struct pci_device_id {
	u32 vendor, device;
	u32 subvendor, subdevice;
	u32 class, class_mask;
	kernel_ulong_t driver_data;
	u32 override_only;
};
#define PCI_DEVICE(v, d) \
	.vendor = (v), .device = (d), .subvendor = PCI_ANY_ID, .subdevice = PCI_ANY_ID
#define PCI_DEVICE_SUB(v, d, sv, sd) \
	.vendor = (v), .device = (d), .subvendor = (sv), .subdevice = (sd)
#define PCI_VDEVICE(v, d) \
	.vendor = PCI_VENDOR_ID_##v, .device = (d), .subvendor = PCI_ANY_ID, .subdevice = PCI_ANY_ID, 0, 0
#define PCI_DEVICE_CLASS(c, m) \
	.class = (c), .class_mask = (m), .vendor = PCI_ANY_ID, .device = PCI_ANY_ID, \
	.subvendor = PCI_ANY_ID, .subdevice = PCI_ANY_ID

#define DEVICE_COUNT_RESOURCE 6
struct pci_bus { unsigned char number; };
struct pci_dev {
	struct device dev;
	struct pci_bus *bus;
	unsigned int devfn;
	unsigned short vendor, device;
	unsigned short subsystem_vendor, subsystem_device;
	unsigned int class;
	u8 revision;
	u8 pcie_cap;
	unsigned int irq;
	struct resource resource[DEVICE_COUNT_RESOURCE];
	unsigned int msi_enabled : 1;
	unsigned int msix_enabled : 1;
	unsigned int no_msi : 1;
	u64 dma_mask;
};
#define to_pci_dev(d) container_of(d, struct pci_dev, dev)

struct pci_driver {
	const char *name;
	const struct pci_device_id *id_table;
	int (*probe)(struct pci_dev *dev, const struct pci_device_id *id);
	void (*remove)(struct pci_dev *dev);
	void (*shutdown)(struct pci_dev *dev);
	int (*suspend)(struct pci_dev *dev, int state);
	int (*resume)(struct pci_dev *dev);
	const void *err_handler;
	struct device_driver driver;
};
int pci_register_driver(struct pci_driver *drv);
void pci_unregister_driver(struct pci_driver *drv);
#define module_pci_driver(drv) \
	static int __init __lde_pci_init(void) { return pci_register_driver(&drv); } \
	module_init(__lde_pci_init)

static inline void *pci_get_drvdata(struct pci_dev *p) { return p->dev.driver_data; }
static inline void pci_set_drvdata(struct pci_dev *p, void *d) { p->dev.driver_data = d; }
static inline const char *pci_name(const struct pci_dev *p) { return dev_name(&p->dev); }
#define pci_resource_start(p, b) ((p)->resource[b].start)
#define pci_resource_end(p, b) ((p)->resource[b].end)
#define pci_resource_flags(p, b) ((p)->resource[b].flags)
#define pci_resource_len(p, b) \
	((p)->resource[b].end ? resource_size(&(p)->resource[b]) : 0)
int pci_enable_device(struct pci_dev *p);
#define pci_enable_device_mem pci_enable_device
#define pcim_enable_device pci_enable_device
void pci_disable_device(struct pci_dev *p);
void pci_set_master(struct pci_dev *p);
void pci_clear_master(struct pci_dev *p);
#define pci_request_regions(p, n) 0
#define pci_release_regions(p) do {} while (0)
#define pci_request_selected_regions(p, b, n) 0
#define pci_release_selected_regions(p, b) do {} while (0)
#define pcim_iomap_regions(p, m, n) 0
#define pci_select_bars(p, f) 0x3f
#define pci_try_set_mwi(p) 0
#define pci_set_mwi(p) 0
#define pci_clear_mwi(p) do {} while (0)
#define pci_save_state(p) 0
#define pci_restore_state(p) do {} while (0)
#define pci_wake_from_d3(p, e) 0
#define pci_enable_wake(p, s, e) 0
#define pci_set_power_state(p, s) 0
#define pci_disable_link_state(p, s) 0
#define pci_is_pcie(p) ((p)->pcie_cap != 0)
#define pci_dev_run_wake(p) 0
#define pci_dev_put(p) do {} while (0)
#define PCI_D0 0
#define PCI_D3hot 3
#define PCI_D3cold 4
int pci_read_config_byte(const struct pci_dev *p, int off, u8 *v);
int pci_read_config_word(const struct pci_dev *p, int off, u16 *v);
int pci_read_config_dword(const struct pci_dev *p, int off, u32 *v);
int pci_write_config_byte(const struct pci_dev *p, int off, u8 v);
int pci_write_config_word(const struct pci_dev *p, int off, u16 v);
int pci_write_config_dword(const struct pci_dev *p, int off, u32 v);
int pci_find_capability(struct pci_dev *p, int cap);
#define PCI_VENDOR_ID 0x00
#define PCI_DEVICE_ID 0x02
#define PCI_COMMAND 0x04
#define PCI_COMMAND_IO 0x1
#define PCI_COMMAND_MEMORY 0x2
#define PCI_COMMAND_MASTER 0x4
#define PCI_COMMAND_INVALIDATE 0x10
#define PCI_COMMAND_PARITY 0x40
#define PCI_COMMAND_SERR 0x100
#define PCI_COMMAND_INTX_DISABLE 0x400
#define PCI_STATUS 0x06
#define PCI_REVISION_ID 0x08
#define PCI_CACHE_LINE_SIZE 0x0c
#define PCI_LATENCY_TIMER 0x0d
#define PCI_BASE_ADDRESS_0 0x10
#define PCI_SUBSYSTEM_VENDOR_ID 0x2c
#define PCI_SUBSYSTEM_ID 0x2e
#define PCI_CAPABILITY_LIST 0x34
#define PCI_INTERRUPT_LINE 0x3c
#define PCI_CAP_ID_PM 0x01
#define PCI_CAP_ID_MSI 0x05
#define PCI_CAP_ID_EXP 0x10
#define PCI_CAP_ID_MSIX 0x11
#define PCI_EXP_DEVCTL 8
#define PCI_EXP_LNKCTL 16
#define PCI_EXP_LNKCTL_ASPM_L0S 0x0001
#define PCI_EXP_LNKCTL_ASPM_L1 0x0002
#define PCI_EXP_LNKCTL_CLKREQ_EN 0x0100

/* прерывания: MSI недоступны, используется линия INTx */
#define PCI_IRQ_INTX (1 << 0)
#define PCI_IRQ_LEGACY PCI_IRQ_INTX
#define PCI_IRQ_MSI (1 << 1)
#define PCI_IRQ_MSIX (1 << 2)
#define PCI_IRQ_ALL_TYPES (PCI_IRQ_INTX | PCI_IRQ_MSI | PCI_IRQ_MSIX)
int pci_alloc_irq_vectors(struct pci_dev *p, unsigned int min, unsigned int max, unsigned int flags);
#define pci_free_irq_vectors(p) do {} while (0)
#define pci_irq_vector(p, n) ((int)(p)->irq)
#define pci_enable_msi(p) (-ENOTSUPP)
#define pci_disable_msi(p) do {} while (0)
#define pci_dev_msi_enabled(p) 0
#define pci_intx(p, e) do {} while (0)

/* ----- ввод-вывод ----- */
/* адреса портов: «cookie» ниже LDE_PIO_LIMIT (как iomap в Linux) */
#define LDE_PIO_BASE 0x10000UL
#define LDE_PIO_LIMIT 0x20000UL
static inline bool __lde_pio(const volatile void __iomem *a) { return (unsigned long)a < LDE_PIO_LIMIT; }
static inline u16 __lde_port(const volatile void __iomem *a) { return (unsigned long)a - LDE_PIO_BASE; }
static inline u8 readb(const volatile void __iomem *a) { return *(const volatile u8 *)a; }
static inline u16 readw(const volatile void __iomem *a) { return *(const volatile u16 *)a; }
static inline u32 readl(const volatile void __iomem *a) { return *(const volatile u32 *)a; }
static inline u64 readq(const volatile void __iomem *a) { return *(const volatile u64 *)a; }
static inline void writeb(u8 v, volatile void __iomem *a) { *(volatile u8 *)a = v; }
static inline void writew(u16 v, volatile void __iomem *a) { *(volatile u16 *)a = v; }
static inline void writel(u32 v, volatile void __iomem *a) { *(volatile u32 *)a = v; }
static inline void writeq(u64 v, volatile void __iomem *a) { *(volatile u64 *)a = v; }
#define readb_relaxed readb
#define readw_relaxed readw
#define readl_relaxed readl
#define writeb_relaxed writeb
#define writew_relaxed writew
#define writel_relaxed writel
#define __raw_readl readl
#define __raw_writel writel
static inline u8 inb(unsigned long p) { return qx_port_in(p, 1); }
static inline u16 inw(unsigned long p) { return qx_port_in(p, 2); }
static inline u32 inl(unsigned long p) { return qx_port_in(p, 4); }
static inline void outb(u8 v, unsigned long p) { qx_port_out(p, 1, v); }
static inline void outw(u16 v, unsigned long p) { qx_port_out(p, 2, v); }
static inline void outl(u32 v, unsigned long p) { qx_port_out(p, 4, v); }
#define inb_p inb
#define outb_p outb
static inline u8 ioread8(const volatile void __iomem *a) { return __lde_pio(a) ? inb(__lde_port(a)) : readb(a); }
static inline u16 ioread16(const volatile void __iomem *a) { return __lde_pio(a) ? inw(__lde_port(a)) : readw(a); }
static inline u32 ioread32(const volatile void __iomem *a) { return __lde_pio(a) ? inl(__lde_port(a)) : readl(a); }
static inline void iowrite8(u8 v, volatile void __iomem *a) { if (__lde_pio(a)) outb(v, __lde_port(a)); else writeb(v, a); }
static inline void iowrite16(u16 v, volatile void __iomem *a) { if (__lde_pio(a)) outw(v, __lde_port(a)); else writew(v, a); }
static inline void iowrite32(u32 v, volatile void __iomem *a) { if (__lde_pio(a)) outl(v, __lde_port(a)); else writel(v, a); }
static inline void memcpy_fromio(void *d, const volatile void __iomem *s, size_t n)
{
	for (size_t i = 0; i < n; i++)
		((u8 *)d)[i] = ioread8((const volatile u8 *)s + i);
}
static inline void memcpy_toio(volatile void __iomem *d, const void *s, size_t n)
{
	for (size_t i = 0; i < n; i++)
		iowrite8(((const u8 *)s)[i], (volatile u8 *)d + i);
}
static inline void memset_io(volatile void __iomem *d, int c, size_t n)
{
	for (size_t i = 0; i < n; i++)
		iowrite8(c, (volatile u8 *)d + i);
}
void __iomem *pci_iomap(struct pci_dev *p, int bar, unsigned long max);
void __iomem *ioremap(resource_size_t phys, size_t size);
#define ioremap_uc ioremap
#define ioremap_wc ioremap
#define pci_iomap_wc pci_iomap
#define pci_iomap_range(p, b, o, m) ((void __iomem *)((u8 __iomem *)pci_iomap(p, b, 0) + (o)))
#define pci_ioremap_bar(p, b) pci_iomap(p, b, 0)
#define pcim_iomap pci_iomap
#define pci_iounmap(p, a) do {} while (0)
#define iounmap(a) do {} while (0)
#define ioport_map(port, n) ((void __iomem *)(LDE_PIO_BASE + (port)))
#define ioport_unmap(a) do {} while (0)

/* ----- DMA ----- */
enum dma_data_direction {
	DMA_BIDIRECTIONAL = 0,
	DMA_TO_DEVICE = 1,
	DMA_FROM_DEVICE = 2,
	DMA_NONE = 3,
};
#define DMA_BIT_MASK(n) (((n) == 64) ? ~0ULL : ((1ULL << (n)) - 1))
#define DMA_MAPPING_ERROR (~(dma_addr_t)0)
void *dma_alloc_coherent(struct device *d, size_t size, dma_addr_t *dma, gfp_t gfp);
void dma_free_coherent(struct device *d, size_t size, void *cpu, dma_addr_t dma);
#define dma_zalloc_coherent dma_alloc_coherent
#define dmam_alloc_coherent dma_alloc_coherent
static inline dma_addr_t dma_map_single(struct device *d, void *p, size_t n, enum dma_data_direction dir)
{
	return qx_virt_to_dma(p);
}
#define dma_unmap_single(d, a, n, dir) do {} while (0)
#define dma_mapping_error(d, a) ((a) == DMA_MAPPING_ERROR)
#define dma_sync_single_for_cpu(d, a, n, dir) barrier()
#define dma_sync_single_for_device(d, a, n, dir) barrier()
#define dma_set_mask(d, m) 0
#define dma_set_coherent_mask(d, m) 0
#define dma_set_mask_and_coherent(d, m) 0
#define pci_set_dma_mask(p, m) 0
#define pci_set_consistent_dma_mask(p, m) 0
#define DEFINE_DMA_UNMAP_ADDR(n) dma_addr_t n
#define DEFINE_DMA_UNMAP_LEN(n) u32 n
#define dma_unmap_addr(p, n) ((p)->n)
#define dma_unmap_addr_set(p, n, v) ((p)->n = (v))
#define dma_unmap_len(p, n) ((p)->n)
#define dma_unmap_len_set(p, n, v) ((p)->n = (v))

/* ----- прерывания ----- */
typedef enum irqreturn {
	IRQ_NONE = 0,
	IRQ_HANDLED = 1,
	IRQ_WAKE_THREAD = 2,
} irqreturn_t;
#define IRQ_RETVAL(x) ((x) ? IRQ_HANDLED : IRQ_NONE)
typedef irqreturn_t (*irq_handler_t)(int, void *);
#define IRQF_SHARED 0x80
#define IRQF_ONESHOT 0x2000
#define IRQF_NO_SUSPEND 0x4000
int request_irq(unsigned int irq, irq_handler_t h, unsigned long flags, const char *name, void *dev);
int request_threaded_irq(unsigned int irq, irq_handler_t h, irq_handler_t t, unsigned long flags,
			 const char *name, void *dev);
#define devm_request_irq(d, i, h, f, n, x) request_irq(i, h, f, n, x)
void free_irq(unsigned int irq, void *dev);
void disable_irq(unsigned int irq);
void enable_irq(unsigned int irq);
#define disable_irq_nosync disable_irq
#define synchronize_irq(i) do {} while (0)
#define enable_irq_wake(i) 0
#define disable_irq_wake(i) 0

#endif
