// SPDX-License-Identifier: GPL-2.0
/* Quadrix LDE: форматированный вывод (vsnprintf, printk). */
#include <lde/kernel.h>

struct out {
	char *buf;
	size_t size, pos;
};

static void put(struct out *o, char c)
{
	if (o->pos + 1 < o->size)
		o->buf[o->pos] = c;
	o->pos++;
}

static void puts_n(struct out *o, const char *s, int prec)
{
	for (int i = 0; s[i] && (prec < 0 || i < prec); i++)
		put(o, s[i]);
}

static void number(struct out *o, unsigned long long v, bool neg, int base, bool upper,
		   int width, int prec, bool left, bool zero, char sign, bool alt)
{
	const char *digits = upper ? "0123456789ABCDEF" : "0123456789abcdef";
	char tmp[24];
	int n = 0;
	do {
		tmp[n++] = digits[v % base];
		v /= base;
	} while (v);
	while (n < prec)
		tmp[n++] = '0';
	char pre[3];
	int np = 0;
	if (neg)
		pre[np++] = '-';
	else if (sign)
		pre[np++] = sign;
	if (alt && base == 16) {
		pre[np++] = '0';
		pre[np++] = upper ? 'X' : 'x';
	}
	int pad = width - n - np;
	if (!left && !zero)
		for (; pad > 0; pad--)
			put(o, ' ');
	for (int i = 0; i < np; i++)
		put(o, pre[i]);
	if (!left && zero)
		for (; pad > 0; pad--)
			put(o, '0');
	while (n)
		put(o, tmp[--n]);
	for (; pad > 0; pad--)
		put(o, ' ');
}

static void hexbyte(struct out *o, u8 b)
{
	put(o, "0123456789abcdef"[b >> 4]);
	put(o, "0123456789abcdef"[b & 15]);
}

/* расширения %p: %pM, %pm, %pI4, %ph, %pe, %pa */
static const char *pointer(struct out *o, const char *f, const void *p, int width)
{
	const u8 *b = p;
	switch (*f) {
	case 'M':
	case 'm':
		for (int i = 0; i < 6; i++) {
			if (i && *f == 'M')
				put(o, ':');
			hexbyte(o, b[i]);
		}
		return f + 1 + (f[1] == 'R' || f[1] == 'F');
	case 'I':
		if (f[1] == '4') {
			for (int i = 0; i < 4; i++) {
				if (i)
					put(o, '.');
				number(o, b[i], false, 10, false, 0, 0, false, false, 0, false);
			}
			return f + 2;
		}
		break;
	case 'h':
		for (int i = 0; i < (width > 0 ? width : 1); i++) {
			if (i && f[1] != 'N')
				put(o, f[1] == 'C' ? ':' : f[1] == 'D' ? '-' : ' ');
			hexbyte(o, b[i]);
		}
		return f + 1 + (f[1] == 'C' || f[1] == 'D' || f[1] == 'N');
	case 'e':
		put(o, 'E');
		number(o, -(long)p, false, 10, false, 0, 0, false, false, 0, false);
		return f + 1;
	case 'a':
		number(o, *(const u64 *)p, false, 16, false, 18, 16, false, true, 0, true);
		return f + 1 + (f[1] == 'd' || f[1] == 'p');
	case 's':
	case 'S':
	case 'B':
		number(o, (unsigned long)p, false, 16, false, 0, 0, false, false, 0, true);
		return f + 1;
	}
	/* как в Linux: 16 цифр без «0x» */
	number(o, (unsigned long)p, false, 16, false, 16, 0, false, true, 0, false);
	return f;
}

int vsnprintf(char *buf, size_t size, const char *f, va_list ap)
{
	struct out o = { buf, size, 0 };
	for (; *f; f++) {
		if (*f != '%') {
			put(&o, *f);
			continue;
		}
		f++;
		bool left = false, zero = false, alt = false;
		char sign = 0;
		for (;; f++) {
			if (*f == '-')
				left = true;
			else if (*f == '0')
				zero = true;
			else if (*f == '+')
				sign = '+';
			else if (*f == ' ')
				sign = sign ? sign : ' ';
			else if (*f == '#')
				alt = true;
			else
				break;
		}
		int width = 0, prec = -1;
		if (*f == '*') {
			width = va_arg(ap, int);
			if (width < 0) {
				left = true;
				width = -width;
			}
			f++;
		} else {
			while (isdigit(*f))
				width = width * 10 + (*f++ - '0');
		}
		if (*f == '.') {
			f++;
			prec = 0;
			if (*f == '*') {
				prec = va_arg(ap, int);
				f++;
			} else {
				while (isdigit(*f))
					prec = prec * 10 + (*f++ - '0');
			}
		}
		int len = 0; /* 0 int, 1 long, 2 long long, -1 short, -2 char */
		for (;; f++) {
			if (*f == 'l')
				len++;
			else if (*f == 'h')
				len--;
			else if (*f == 'z' || *f == 't' || *f == 'j')
				len = 1;
			else
				break;
		}
		unsigned long long v;
		bool neg = false;
		switch (*f) {
		case 'd':
		case 'i': {
			long long s = len >= 2 ? va_arg(ap, long long) : len == 1 ? va_arg(ap, long) : va_arg(ap, int);
			if (len == -1)
				s = (short)s;
			else if (len <= -2)
				s = (signed char)s;
			neg = s < 0;
			v = neg ? -(unsigned long long)s : (unsigned long long)s;
			number(&o, v, neg, 10, false, width, prec, left, zero && prec < 0, sign, false);
			break;
		}
		case 'u':
		case 'x':
		case 'X':
		case 'o':
			v = len >= 2 ? va_arg(ap, unsigned long long) : len == 1 ? va_arg(ap, unsigned long) : va_arg(ap, unsigned int);
			if (len == -1)
				v = (unsigned short)v;
			else if (len <= -2)
				v = (unsigned char)v;
			number(&o, v, false, *f == 'u' ? 10 : *f == 'o' ? 8 : 16, *f == 'X', width, prec,
			       left, zero && prec < 0, 0, alt);
			break;
		case 'c':
			put(&o, (char)va_arg(ap, int));
			break;
		case 's': {
			const char *s = va_arg(ap, const char *);
			if (!s)
				s = "(null)";
			int n = prec < 0 ? (int)strlen(s) : (int)strnlen(s, prec);
			if (!left)
				for (int i = n; i < width; i++)
					put(&o, ' ');
			puts_n(&o, s, prec);
			if (left)
				for (int i = n; i < width; i++)
					put(&o, ' ');
			break;
		}
		case 'p':
			f = pointer(&o, f + 1, va_arg(ap, void *), width) - 1;
			break;
		case '%':
			put(&o, '%');
			break;
		case 0:
			f--;
			break;
		default:
			put(&o, '%');
			put(&o, *f);
		}
	}
	if (size)
		buf[o.pos < size ? o.pos : size - 1] = 0;
	return o.pos;
}

int vscnprintf(char *buf, size_t size, const char *fmt, va_list ap)
{
	int n = vsnprintf(buf, size, fmt, ap);
	if (!size)
		return 0;
	return (size_t)n < size ? n : (int)size - 1;
}

int snprintf(char *buf, size_t size, const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	int n = vsnprintf(buf, size, fmt, ap);
	va_end(ap);
	return n;
}

int scnprintf(char *buf, size_t size, const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	int n = vscnprintf(buf, size, fmt, ap);
	va_end(ap);
	return n;
}

int sprintf(char *buf, const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	int n = vsnprintf(buf, ~0UL >> 1, fmt, ap);
	va_end(ap);
	return n;
}

/* строки собираются до перевода строки (pr_cont) и уходят в журнал */
static char line[512];
static size_t line_len;

int printk(const char *fmt, ...)
{
	if (fmt[0] == KERN_SOH[0] && fmt[1]) {
		if (fmt[1] == '7')
			return 0; /* отладка */
		fmt += 2;
	}
	va_list ap;
	va_start(ap, fmt);
	int n = vscnprintf(line + line_len, sizeof(line) - line_len, fmt, ap);
	va_end(ap);
	line_len += n;
	while (line_len) {
		char *nl = memchr(line, '\n', line_len);
		if (!nl && line_len < sizeof(line) - 1)
			break;
		size_t len = nl ? (size_t)(nl - line) : line_len;
		qx_log(line, len);
		size_t rest = line_len - len - (nl ? 1 : 0);
		memmove(line, line + line_len - rest, rest);
		line_len = rest;
	}
	return n;
}

void print_hex_dump(const char *level, const char *prefix, int type, int rowsize,
		    int groupsize, const void *buf, size_t len, bool ascii)
{
	const u8 *b = buf;
	for (size_t i = 0; i < len; i += rowsize) {
		char row[128];
		size_t n = scnprintf(row, sizeof(row), "%s%04zx:", prefix, i);
		for (size_t j = i; j < len && j < i + rowsize && n < sizeof(row) - 4; j++)
			n += scnprintf(row + n, sizeof(row) - n, " %02x", b[j]);
		printk("%s%s\n", level, row);
	}
}

void lde_bug(const char *file, int line)
{
	printk(KERN_CRIT "BUG at %s:%d\n", file, line);
	qx_abort();
}
