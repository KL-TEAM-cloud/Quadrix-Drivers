// SPDX-License-Identifier: GPL-2.0
/* Quadrix LDE: сетевой интерфейс драйвера. Принятые кадры уходят в
 * netd (qx_net_rx), кадры от netd передаются драйверу через
 * ndo_start_xmit. */
#include <lde/kernel.h>

static struct net_device *lde_netdev;
static LIST_HEAD(napi_list);

struct net_device *alloc_etherdev_mqs(int sizeof_priv, unsigned int txqs, unsigned int rxqs)
{
	size_t off = ALIGN(sizeof(struct net_device), 64);
	struct net_device *dev = kzalloc(off + sizeof_priv, GFP_KERNEL);
	if (!dev)
		return NULL;
	dev->lde_priv = (u8 *)dev + off;
	strscpy(dev->name, "eth%d");
	dev->type = 1; /* ARPHRD_ETHER */
	dev->hard_header_len = ETH_HLEN;
	dev->mtu = ETH_DATA_LEN;
	dev->min_mtu = ETH_MIN_MTU;
	dev->max_mtu = ETH_DATA_LEN;
	dev->addr_len = ETH_ALEN;
	dev->tx_queue_len = 1000;
	dev->flags = IFF_BROADCAST | IFF_MULTICAST;
	dev->dev_addr = dev->lde_addr;
	dev->num_tx_queues = dev->real_num_tx_queues = txqs;
	dev->gso_max_size = 65536;
	memset(dev->broadcast, 0xff, ETH_ALEN);
	INIT_LIST_HEAD(&dev->mc.list);
	INIT_LIST_HEAD(&dev->uc.list);
	set_bit(__LINK_STATE_PRESENT, &dev->state);
	return dev;
}

void free_netdev(struct net_device *dev)
{
	if (dev == lde_netdev)
		lde_netdev = NULL;
	kfree(dev);
}

int register_netdev(struct net_device *dev)
{
	if (lde_netdev)
		return -EBUSY;
	strscpy(dev->name, "eth0");
	if (is_zero_ether_addr(dev->perm_addr))
		memcpy(dev->perm_addr, dev->dev_addr, ETH_ALEN);
	if (dev->netdev_ops->ndo_init) {
		int r = dev->netdev_ops->ndo_init(dev);
		if (r)
			return r;
	}
	dev->registered = true;
	lde_netdev = dev;
	return 0;
}

void unregister_netdev(struct net_device *dev)
{
	if (netif_running(dev) && dev->netdev_ops->ndo_stop)
		dev->netdev_ops->ndo_stop(dev);
	clear_bit(__LINK_STATE_START, &dev->state);
	dev->registered = false;
	if (dev == lde_netdev)
		lde_netdev = NULL;
}

int lde_has_netdev(void)
{
	return lde_netdev != NULL;
}

void lde_net_mac(u8 mac[6])
{
	if (lde_netdev)
		memcpy(mac, lde_netdev->dev_addr, ETH_ALEN);
}

int lde_net_open(void)
{
	struct net_device *dev = lde_netdev;
	if (!dev)
		return -ENODEV;
	/* как __dev_open: состояние START до ndo_open */
	set_bit(__LINK_STATE_START, &dev->state);
	int r = dev->netdev_ops->ndo_open ? dev->netdev_ops->ndo_open(dev) : 0;
	if (r) {
		clear_bit(__LINK_STATE_START, &dev->state);
		return r;
	}
	dev->flags |= IFF_UP;
	if (dev->netdev_ops->ndo_set_rx_mode)
		dev->netdev_ops->ndo_set_rx_mode(dev);
	qx_net_carrier(netif_carrier_ok(dev));
	return 0;
}

void netif_carrier_on(struct net_device *dev)
{
	if (test_and_clear_bit(__LINK_STATE_NOCARRIER, &dev->state) && dev == lde_netdev)
		qx_net_carrier(1);
}

void netif_carrier_off(struct net_device *dev)
{
	if (!test_and_set_bit(__LINK_STATE_NOCARRIER, &dev->state) && dev == lde_netdev)
		qx_net_carrier(0);
}

int lde_tx_ready(void)
{
	struct net_device *dev = lde_netdev;
	return dev && netif_running(dev) && !netif_queue_stopped(dev) && netif_device_present(dev);
}

int lde_xmit(const void *data, size_t len)
{
	struct net_device *dev = lde_netdev;
	if (!lde_tx_ready())
		return -EBUSY;
	struct sk_buff *skb = netdev_alloc_skb(dev, len < ETH_ZLEN ? ETH_ZLEN : len);
	if (!skb)
		return -ENOMEM;
	skb_put_data(skb, data, len);
	skb->dev = dev;
	skb->protocol = len >= ETH_HLEN ? *(const __be16 *)((const u8 *)data + 12) : 0;
	skb->ip_summed = CHECKSUM_NONE;
	if (dev->netdev_ops->ndo_start_xmit(skb, dev) != NETDEV_TX_OK) {
		kfree_skb(skb);
		return -EBUSY;
	}
	netif_trans_update(dev);
	return 0;
}

/* ----- sk_buff ----- */
struct sk_buff *alloc_skb(unsigned int size, gfp_t gfp)
{
	struct sk_buff *skb = kzalloc(sizeof(*skb), gfp);
	if (!skb)
		return NULL;
	size = ALIGN(size, SMP_CACHE_BYTES);
	u8 *buf = kmalloc(size, gfp);
	if (!buf) {
		kfree(skb);
		return NULL;
	}
	skb->head = skb->data = skb->tail = buf;
	skb->end = buf + size;
	skb->truesize = size + sizeof(*skb);
	return skb;
}

struct sk_buff *__netdev_alloc_skb(struct net_device *dev, unsigned int len, gfp_t gfp)
{
	struct sk_buff *skb = alloc_skb(len + NET_SKB_PAD, gfp);
	if (skb) {
		skb_reserve(skb, NET_SKB_PAD);
		skb->dev = dev;
	}
	return skb;
}

struct sk_buff *napi_alloc_skb(struct napi_struct *n, unsigned int len)
{
	return __netdev_alloc_skb(n->dev, len + NET_IP_ALIGN, GFP_ATOMIC);
}

void kfree_skb(struct sk_buff *skb)
{
	if (!skb)
		return;
	kfree(skb->head);
	kfree(skb);
}

void skb_copy_and_csum_dev(const struct sk_buff *skb, u8 *to)
{
	/* netd сам считает контрольные суммы: CHECKSUM_PARTIAL не бывает */
	memcpy(to, skb->data, skb_headlen(skb));
}

int skb_padto(struct sk_buff *skb, unsigned int len)
{
	if (skb->len >= len)
		return 0;
	if ((unsigned int)skb_tailroom(skb) < len - skb->len) {
		kfree_skb(skb);
		return -ENOMEM;
	}
	memset(skb->data + skb->len, 0, len - skb->len);
	return 0;
}

int skb_checksum_help(struct sk_buff *skb)
{
	return 0;
}

__be16 eth_type_trans(struct sk_buff *skb, struct net_device *dev)
{
	skb->dev = dev;
	skb_reset_mac_header(skb);
	const struct ethhdr *eth = (const struct ethhdr *)skb->data;
	skb_pull(skb, ETH_HLEN);
	if (is_multicast_ether_addr(eth->h_dest))
		skb->pkt_type = is_broadcast_ether_addr(eth->h_dest) ? PACKET_BROADCAST : PACKET_MULTICAST;
	else if (!ether_addr_equal(eth->h_dest, dev->dev_addr))
		skb->pkt_type = PACKET_OTHERHOST;
	if (ntohs(eth->h_proto) >= ETH_P_802_3_MIN)
		return eth->h_proto;
	return htons(ETH_P_802_2);
}

int netif_receive_skb(struct sk_buff *skb)
{
	if (skb->pkt_type != PACKET_OTHERHOST)
		qx_net_rx(skb_mac_header(skb), skb->len + (skb->data - skb_mac_header(skb)));
	kfree_skb(skb);
	return 0;
}

int eth_validate_addr(struct net_device *dev)
{
	return is_valid_ether_addr(dev->dev_addr) ? 0 : -EADDRNOTAVAIL;
}

int eth_mac_addr(struct net_device *dev, void *p)
{
	struct sockaddr *a = p;
	if (!is_valid_ether_addr((u8 *)a->sa_data))
		return -EADDRNOTAVAIL;
	eth_hw_addr_set(dev, (u8 *)a->sa_data);
	return 0;
}

void netdev_stats_to_stats64(struct rtnl_link_stats64 *s64, const struct net_device_stats *s)
{
	const unsigned long *src = (const unsigned long *)s;
	u64 *dst = (u64 *)s64;
	size_t n = sizeof(*s) / sizeof(unsigned long);
	for (size_t i = 0; i < n; i++)
		dst[i] = src[i];
	for (size_t i = n; i < sizeof(*s64) / sizeof(u64); i++)
		dst[i] = 0;
}

u32 ethtool_op_get_link(struct net_device *dev)
{
	return netif_carrier_ok(dev) ? 1 : 0;
}

void ethtool_convert_legacy_u32_to_link_mode(unsigned long *dst, u32 legacy_u32)
{
	linkmode_zero(dst);
	dst[0] = legacy_u32;
}

bool ethtool_convert_link_mode_to_legacy_u32(u32 *legacy_u32, const unsigned long *src)
{
	bool ok = (src[0] >> 32) == 0;
	for (unsigned i = 1; i < BITS_TO_LONGS(__ETHTOOL_LINK_MODE_MASK_NBITS); i++)
		ok &= src[i] == 0;
	*legacy_u32 = src[0];
	return ok;
}

/* ----- NAPI ----- */
void netif_napi_add_weight(struct net_device *dev, struct napi_struct *n,
			   int (*poll)(struct napi_struct *, int), int weight)
{
	n->dev = dev;
	n->poll = poll;
	n->weight = weight;
	n->state = BIT(NAPI_STATE_SCHED);
	n->enabled = false;
	list_add_tail(&n->list, &napi_list);
}

void netif_napi_del(struct napi_struct *n)
{
	list_del(&n->list);
}

void napi_enable(struct napi_struct *n)
{
	n->enabled = true;
	clear_bit(NAPI_STATE_SCHED, &n->state);
}

void napi_disable(struct napi_struct *n)
{
	n->enabled = false;
	set_bit(NAPI_STATE_SCHED, &n->state);
}

bool napi_schedule_prep(struct napi_struct *n)
{
	return n->enabled && !test_and_set_bit(NAPI_STATE_SCHED, &n->state);
}

void __napi_schedule(struct napi_struct *n)
{
	set_bit(NAPI_STATE_SCHED, &n->state);
}

bool napi_complete_done(struct napi_struct *n, int work)
{
	clear_bit(NAPI_STATE_SCHED, &n->state);
	return true;
}

/* опрос запланированных NAPI; true — нужен ещё один проход */
bool lde_napi_run(void)
{
	bool more = false;
	struct napi_struct *n;
	list_for_each_entry(n, &napi_list, list) {
		if (!n->enabled || !test_bit(NAPI_STATE_SCHED, &n->state))
			continue;
		int work = n->poll(n, n->weight);
		if (work >= n->weight && test_bit(NAPI_STATE_SCHED, &n->state))
			more = true;
	}
	return more;
}
