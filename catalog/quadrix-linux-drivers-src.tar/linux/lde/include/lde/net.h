/* SPDX-License-Identifier: GPL-2.0 */
/* Quadrix LDE: сетевые устройства Linux — sk_buff, net_device, NAPI,
 * ethtool. Кадры принятые драйвером уходят в netd через qx_net_rx(). */
#ifndef _LDE_NET_H
#define _LDE_NET_H

#include <lde/pci.h>
#include <linux/if_ether.h>
#include <uapi/linux/ethtool.h>

/* ----- интерфейсы ----- */
#define IFNAMSIZ 16
#define IFALIASZ 256
#define IFF_UP 0x1
#define IFF_BROADCAST 0x2
#define IFF_DEBUG 0x4
#define IFF_LOOPBACK 0x8
#define IFF_POINTOPOINT 0x10
#define IFF_NOTRAILERS 0x20
#define IFF_RUNNING 0x40
#define IFF_NOARP 0x80
#define IFF_PROMISC 0x100
#define IFF_ALLMULTI 0x200
#define IFF_MULTICAST 0x1000
/* priv_flags */
#define IFF_UNICAST_FLT (1 << 12)
#define IFF_LIVE_ADDR_CHANGE (1 << 15)
#define IFF_SUPP_NOFCS (1 << 19)
#define IFF_TX_SKB_NO_LINEAR (1 << 31)

typedef unsigned short sa_family_t;
struct sockaddr {
	sa_family_t sa_family;
	char sa_data[14];
};
struct ifmap {
	unsigned long mem_start, mem_end;
	unsigned short base_addr;
	unsigned char irq, dma, port;
};
struct ifreq {
	union {
		char ifrn_name[IFNAMSIZ];
	} ifr_ifrn;
	union {
		struct sockaddr ifru_addr;
		struct sockaddr ifru_hwaddr;
		short ifru_flags;
		int ifru_ivalue;
		int ifru_mtu;
		struct ifmap ifru_map;
		char ifru_slave[IFNAMSIZ];
		char ifru_newname[IFNAMSIZ];
		void __user *ifru_data;
	} ifr_ifru;
};
#define ifr_name ifr_ifrn.ifrn_name
#define ifr_data ifr_ifru.ifru_data
#define SIOCGMIIPHY 0x8947
#define SIOCGMIIREG 0x8948
#define SIOCSMIIREG 0x8949
#define SIOCSHWTSTAMP 0x89b0
#define SIOCGHWTSTAMP 0x89b1
#define capable(c) 1
#define CAP_NET_ADMIN 12

/* ----- статистика ----- */
struct net_device_stats {
	unsigned long rx_packets, tx_packets, rx_bytes, tx_bytes;
	unsigned long rx_errors, tx_errors, rx_dropped, tx_dropped;
	unsigned long multicast, collisions;
	unsigned long rx_length_errors, rx_over_errors, rx_crc_errors;
	unsigned long rx_frame_errors, rx_fifo_errors, rx_missed_errors;
	unsigned long tx_aborted_errors, tx_carrier_errors, tx_fifo_errors;
	unsigned long tx_heartbeat_errors, tx_window_errors;
	unsigned long rx_compressed, tx_compressed;
};
struct rtnl_link_stats64 {
	u64 rx_packets, tx_packets, rx_bytes, tx_bytes;
	u64 rx_errors, tx_errors, rx_dropped, tx_dropped;
	u64 multicast, collisions;
	u64 rx_length_errors, rx_over_errors, rx_crc_errors;
	u64 rx_frame_errors, rx_fifo_errors, rx_missed_errors;
	u64 tx_aborted_errors, tx_carrier_errors, tx_fifo_errors;
	u64 tx_heartbeat_errors, tx_window_errors;
	u64 rx_compressed, tx_compressed, rx_nohandler, rx_otherhost_dropped;
};
void netdev_stats_to_stats64(struct rtnl_link_stats64 *s64, const struct net_device_stats *s);
struct u64_stats_sync { int unused; };
typedef struct { u64 v; } u64_stats_t;
#define u64_stats_init(s) ((void)(s))
#define u64_stats_update_begin(s) ((void)(s))
#define u64_stats_update_end(s) ((void)(s))
#define u64_stats_update_begin_irqsave(s) ({ (void)(s); 0UL; })
#define u64_stats_update_end_irqrestore(s, f) ((void)(s), (void)(f))
#define u64_stats_fetch_begin(s) ({ (void)(s); 0U; })
#define u64_stats_fetch_retry(s, st) ((void)(s), (void)(st), false)
#define u64_stats_read(p) ((p)->v)
#define u64_stats_set(p, x) ((p)->v = (x))
#define u64_stats_add(p, x) ((p)->v += (x))
#define u64_stats_inc(p) ((p)->v++)

/* ----- возможности ----- */
#define NETIF_F_SG BIT_ULL(0)
#define NETIF_F_IP_CSUM BIT_ULL(1)
#define NETIF_F_HW_CSUM BIT_ULL(3)
#define NETIF_F_IPV6_CSUM BIT_ULL(4)
#define NETIF_F_HIGHDMA BIT_ULL(5)
#define NETIF_F_HW_VLAN_CTAG_TX BIT_ULL(7)
#define NETIF_F_HW_VLAN_CTAG_RX BIT_ULL(8)
#define NETIF_F_TSO BIT_ULL(16)
#define NETIF_F_TSO6 BIT_ULL(20)
#define NETIF_F_RXCSUM BIT_ULL(32)
#define NETIF_F_RXFCS BIT_ULL(38)
#define NETIF_F_RXALL BIT_ULL(39)
#define NETIF_F_GSO_SHIFT 16
#define NETIF_F_CSUM_MASK (NETIF_F_IP_CSUM | NETIF_F_HW_CSUM | NETIF_F_IPV6_CSUM)
#define NETIF_F_ALL_TSO (NETIF_F_TSO | NETIF_F_TSO6)

/* ----- sk_buff ----- */
#define CHECKSUM_NONE 0
#define CHECKSUM_UNNECESSARY 1
#define CHECKSUM_COMPLETE 2
#define CHECKSUM_PARTIAL 3
#define PACKET_HOST 0
#define PACKET_BROADCAST 1
#define PACKET_MULTICAST 2
#define PACKET_OTHERHOST 3
#define NET_IP_ALIGN 0
#define NET_SKB_PAD 64
#define MAX_SKB_FRAGS 17

struct net_device;
typedef struct skb_frag {
	void *page;
	unsigned int offset, len;
} skb_frag_t;
struct skb_shared_info {
	u8 nr_frags;
	u8 tx_flags;
	unsigned short gso_size;
	unsigned short gso_segs;
	unsigned int gso_type;
	skb_frag_t frags[MAX_SKB_FRAGS];
};
struct sk_buff {
	struct sk_buff *next, *prev;
	struct net_device *dev;
	unsigned int len, data_len;
	__be16 protocol;
	u8 ip_summed;
	u8 pkt_type;
	u16 queue_mapping;
	u32 priority;
	__wsum csum;
	u16 csum_start, csum_offset;
	u16 vlan_tci;
	__be16 vlan_proto;
	u16 mac_header, network_header, transport_header;
	unsigned int truesize;
	unsigned char *head, *data, *tail, *end;
	char cb[48] __aligned(8);
	struct skb_shared_info shinfo;
};
struct sk_buff_head {
	struct sk_buff *next, *prev;
	u32 qlen;
	spinlock_t lock;
};
#define skb_shinfo(skb) (&(skb)->shinfo)
struct sk_buff *alloc_skb(unsigned int size, gfp_t gfp);
struct sk_buff *__netdev_alloc_skb(struct net_device *dev, unsigned int len, gfp_t gfp);
#define netdev_alloc_skb(dev, len) __netdev_alloc_skb(dev, len, GFP_ATOMIC)
#define netdev_alloc_skb_ip_align(dev, len) netdev_alloc_skb(dev, len)
#define dev_alloc_skb(len) netdev_alloc_skb(NULL, len)
struct napi_struct;
struct sk_buff *napi_alloc_skb(struct napi_struct *n, unsigned int len);
void kfree_skb(struct sk_buff *skb);
#define consume_skb kfree_skb
#define dev_kfree_skb kfree_skb
#define dev_kfree_skb_any kfree_skb
#define dev_kfree_skb_irq kfree_skb
#define dev_consume_skb_any kfree_skb
#define dev_consume_skb_irq kfree_skb
#define napi_consume_skb(skb, b) kfree_skb(skb)
#define kfree_skb_reason(skb, r) kfree_skb(skb)
static inline unsigned int skb_headlen(const struct sk_buff *s) { return s->len - s->data_len; }
static inline bool skb_is_nonlinear(const struct sk_buff *s) { return s->data_len != 0; }
static inline unsigned int skb_headroom(const struct sk_buff *s) { return s->data - s->head; }
static inline int skb_tailroom(const struct sk_buff *s) { return s->end - s->tail; }
static inline unsigned char *skb_tail_pointer(const struct sk_buff *s) { return s->tail; }
static inline void skb_reserve(struct sk_buff *s, int n) { s->data += n; s->tail += n; }
static inline void *skb_put(struct sk_buff *s, unsigned int n)
{
	void *t = s->tail;
	s->tail += n;
	s->len += n;
	return t;
}
static inline void *__skb_put(struct sk_buff *s, unsigned int n) { return skb_put(s, n); }
static inline void *skb_put_data(struct sk_buff *s, const void *d, unsigned int n)
{
	void *t = skb_put(s, n);
	memcpy(t, d, n);
	return t;
}
static inline void *skb_put_zero(struct sk_buff *s, unsigned int n)
{
	void *t = skb_put(s, n);
	memset(t, 0, n);
	return t;
}
static inline void *skb_push(struct sk_buff *s, unsigned int n) { s->data -= n; s->len += n; return s->data; }
static inline void *skb_pull(struct sk_buff *s, unsigned int n)
{
	if (n > s->len)
		return NULL;
	s->len -= n;
	return s->data += n;
}
#define __skb_pull skb_pull
static inline void skb_trim(struct sk_buff *s, unsigned int len)
{
	if (s->len > len) {
		s->len = len;
		s->tail = s->data + len;
	}
}
#define __skb_trim skb_trim
static inline void skb_copy_to_linear_data(struct sk_buff *s, const void *f, unsigned int n) { memcpy(s->data, f, n); }
static inline void skb_copy_to_linear_data_offset(struct sk_buff *s, int o, const void *f, unsigned int n) { memcpy(s->data + o, f, n); }
static inline void skb_copy_from_linear_data(const struct sk_buff *s, void *t, unsigned int n) { memcpy(t, s->data, n); }
static inline void skb_copy_from_linear_data_offset(const struct sk_buff *s, int o, void *t, unsigned int n) { memcpy(t, s->data + o, n); }
void skb_copy_and_csum_dev(const struct sk_buff *skb, u8 *to);
int skb_padto(struct sk_buff *skb, unsigned int len);
#define skb_put_padto(skb, len) skb_padto(skb, len)
static inline int eth_skb_pad(struct sk_buff *skb) { return skb_padto(skb, ETH_ZLEN); }
int skb_checksum_help(struct sk_buff *skb);
#define skb_linearize(skb) 0
#define skb_tx_timestamp(skb) do {} while (0)
#define skb_record_rx_queue(skb, q) do {} while (0)
#define skb_get_queue_mapping(skb) 0
#define skb_checksum_none_assert(skb) do {} while (0)
#define skb_vlan_tag_present(skb) 0
#define skb_vlan_tag_get(skb) 0
#define __vlan_hwaccel_put_tag(skb, p, t) do {} while (0)
#define skb_is_gso(skb) 0
#define skb_is_gso_v6(skb) 0
#define skb_transport_offset(skb) 0
#define skb_checksum_start_offset(skb) 0
#define skb_mark_for_recycle(skb) do {} while (0)
#define skb_reset_mac_header(skb) ((skb)->mac_header = (skb)->data - (skb)->head)
static inline unsigned char *skb_mac_header(const struct sk_buff *s) { return s->head + s->mac_header; }
#define skb_queue_head_init(q) ((q)->next = (q)->prev = (struct sk_buff *)(q), (q)->qlen = 0)
#define skb_queue_len(q) ((q)->qlen)
#define skb_queue_empty(q) ((q)->qlen == 0)
static inline void skb_queue_tail(struct sk_buff_head *q, struct sk_buff *s)
{
	struct sk_buff *last = q->prev;
	s->next = (struct sk_buff *)q;
	s->prev = last;
	last->next = s;
	q->prev = s;
	q->qlen++;
}
#define __skb_queue_tail skb_queue_tail
static inline struct sk_buff *skb_dequeue(struct sk_buff_head *q)
{
	struct sk_buff *s = q->next;
	if (s == (struct sk_buff *)q)
		return NULL;
	q->next = s->next;
	s->next->prev = (struct sk_buff *)q;
	q->qlen--;
	s->next = s->prev = NULL;
	return s;
}
#define __skb_dequeue skb_dequeue
static inline void skb_queue_purge(struct sk_buff_head *q)
{
	struct sk_buff *s;
	while ((s = skb_dequeue(q)))
		kfree_skb(s);
}
#define __skb_queue_purge skb_queue_purge
static inline unsigned int skb_frag_size(const skb_frag_t *f) { return f->len; }
#define skb_frag_address(f) ((u8 *)(f)->page + (f)->offset)

/* ----- NAPI ----- */
#define NAPI_POLL_WEIGHT 64
struct napi_struct {
	struct list_head list;
	struct net_device *dev;
	int (*poll)(struct napi_struct *, int);
	int weight;
	unsigned long state;
	bool enabled;
};
#define NAPI_STATE_SCHED 0
void netif_napi_add_weight(struct net_device *dev, struct napi_struct *n,
			   int (*poll)(struct napi_struct *, int), int weight);
#define netif_napi_add(dev, n, poll) netif_napi_add_weight(dev, n, poll, NAPI_POLL_WEIGHT)
#define netif_napi_add_tx netif_napi_add
void netif_napi_del(struct napi_struct *n);
void napi_enable(struct napi_struct *n);
void napi_disable(struct napi_struct *n);
bool napi_schedule_prep(struct napi_struct *n);
void __napi_schedule(struct napi_struct *n);
#define __napi_schedule_irqoff __napi_schedule
static inline bool napi_schedule(struct napi_struct *n)
{
	if (napi_schedule_prep(n)) {
		__napi_schedule(n);
		return true;
	}
	return false;
}
#define napi_schedule_irqoff napi_schedule
bool napi_complete_done(struct napi_struct *n, int work);
#define napi_complete(n) napi_complete_done(n, 0)
#define napi_synchronize(n) do {} while (0)
int netif_receive_skb(struct sk_buff *skb);
#define netif_rx netif_receive_skb
#define netif_receive_skb_list(l) do {} while (0)
#define napi_gro_receive(n, skb) netif_receive_skb(skb)
#define napi_gro_flush(n, f) do {} while (0)

/* ----- сетевое устройство ----- */
#define MAX_ADDR_LEN 32
struct netdev_hw_addr {
	struct list_head list;
	unsigned char addr[MAX_ADDR_LEN];
};
struct netdev_hw_addr_list {
	struct list_head list;
	int count;
};
#define netdev_hw_addr_list_count(l) ((l)->count)
#define netdev_mc_count(dev) ((dev)->mc.count)
#define netdev_mc_empty(dev) (netdev_mc_count(dev) == 0)
#define netdev_uc_count(dev) ((dev)->uc.count)
#define netdev_for_each_mc_addr(ha, dev) list_for_each_entry(ha, &(dev)->mc.list, list)
#define netdev_for_each_uc_addr(ha, dev) list_for_each_entry(ha, &(dev)->uc.list, list)

typedef enum netdev_tx {
	NETDEV_TX_OK = 0x00,
	NETDEV_TX_BUSY = 0x10,
} netdev_tx_t;

struct ethtool_ops;
struct net_device;
struct netdev_queue { int stopped; };
struct net_device_ops {
	int (*ndo_init)(struct net_device *dev);
	void (*ndo_uninit)(struct net_device *dev);
	int (*ndo_open)(struct net_device *dev);
	int (*ndo_stop)(struct net_device *dev);
	netdev_tx_t (*ndo_start_xmit)(struct sk_buff *skb, struct net_device *dev);
	netdev_features_t (*ndo_features_check)(struct sk_buff *skb, struct net_device *dev,
						netdev_features_t features);
	void (*ndo_set_rx_mode)(struct net_device *dev);
	int (*ndo_set_mac_address)(struct net_device *dev, void *addr);
	int (*ndo_validate_addr)(struct net_device *dev);
	int (*ndo_do_ioctl)(struct net_device *dev, struct ifreq *ifr, int cmd);
	int (*ndo_eth_ioctl)(struct net_device *dev, struct ifreq *ifr, int cmd);
	int (*ndo_change_mtu)(struct net_device *dev, int new_mtu);
	void (*ndo_tx_timeout)(struct net_device *dev, unsigned int txqueue);
	void (*ndo_get_stats64)(struct net_device *dev, struct rtnl_link_stats64 *s);
	struct net_device_stats *(*ndo_get_stats)(struct net_device *dev);
	void (*ndo_poll_controller)(struct net_device *dev);
	netdev_features_t (*ndo_fix_features)(struct net_device *dev, netdev_features_t f);
	int (*ndo_set_features)(struct net_device *dev, netdev_features_t f);
	int (*ndo_vlan_rx_add_vid)(struct net_device *dev, __be16 proto, u16 vid);
	int (*ndo_vlan_rx_kill_vid)(struct net_device *dev, __be16 proto, u16 vid);
};

enum netdev_state_t {
	__LINK_STATE_START,
	__LINK_STATE_PRESENT,
	__LINK_STATE_NOCARRIER,
};

struct net_device {
	char name[IFNAMSIZ];
	unsigned long base_addr;
	int irq;
	unsigned long state;
	const struct net_device_ops *netdev_ops;
	const struct ethtool_ops *ethtool_ops;
	unsigned int flags;
	unsigned long long priv_flags;
	unsigned int mtu, min_mtu, max_mtu;
	unsigned short type;
	unsigned short hard_header_len;
	unsigned short needed_headroom, needed_tailroom;
	netdev_features_t features, hw_features, wanted_features, vlan_features;
	netdev_features_t hw_enc_features, mpls_features, gso_partial_features;
	unsigned int gso_max_size, tso_max_size;
	u16 gso_max_segs, tso_max_segs;
	unsigned char if_port;
	unsigned char addr_len;
	unsigned char addr_assign_type;
	const unsigned char *dev_addr;
	unsigned char perm_addr[MAX_ADDR_LEN];
	unsigned char broadcast[MAX_ADDR_LEN];
	struct netdev_hw_addr_list uc, mc;
	struct net_device_stats stats;
	int watchdog_timeo;
	unsigned int tx_queue_len;
	unsigned int num_tx_queues, real_num_tx_queues;
	struct netdev_queue txq;
	struct device dev;
	unsigned long trans_start;
	bool registered;
	/* LDE */
	unsigned char lde_addr[MAX_ADDR_LEN];
	void *lde_priv;
};
#define NET_ADDR_PERM 0
#define NET_ADDR_RANDOM 1
#define SET_NETDEV_DEV(net, pdev) ((net)->dev.parent = (pdev))
#define SET_NETDEV_DEVTYPE(net, t) do {} while (0)
static inline void *netdev_priv(const struct net_device *d) { return d->lde_priv; }
struct net_device *alloc_etherdev_mqs(int sizeof_priv, unsigned int txqs, unsigned int rxqs);
#define alloc_etherdev(s) alloc_etherdev_mqs(s, 1, 1)
#define alloc_etherdev_mq(s, q) alloc_etherdev_mqs(s, q, q)
#define devm_alloc_etherdev(d, s) alloc_etherdev(s)
void free_netdev(struct net_device *dev);
int register_netdev(struct net_device *dev);
#define devm_register_netdev(d, n) register_netdev(n)
void unregister_netdev(struct net_device *dev);
static inline const char *netdev_name(const struct net_device *d) { return d->name; }
static inline struct netdev_queue *netdev_get_tx_queue(struct net_device *d, unsigned int i) { return &d->txq; }

#define netif_running(dev) test_bit(__LINK_STATE_START, &(dev)->state)
#define netif_device_present(dev) test_bit(__LINK_STATE_PRESENT, &(dev)->state)
#define netif_device_detach(dev) clear_bit(__LINK_STATE_PRESENT, &(dev)->state)
#define netif_device_attach(dev) set_bit(__LINK_STATE_PRESENT, &(dev)->state)
#define netif_carrier_ok(dev) (!test_bit(__LINK_STATE_NOCARRIER, &(dev)->state))
void netif_carrier_on(struct net_device *dev);
void netif_carrier_off(struct net_device *dev);
#define netif_start_queue(dev) ((dev)->txq.stopped = 0)
#define netif_stop_queue(dev) ((dev)->txq.stopped = 1)
#define netif_wake_queue(dev) ((dev)->txq.stopped = 0)
#define netif_queue_stopped(dev) ((dev)->txq.stopped)
#define netif_tx_start_all_queues netif_start_queue
#define netif_tx_stop_all_queues netif_stop_queue
#define netif_tx_wake_all_queues netif_wake_queue
#define netif_tx_disable netif_stop_queue
#define netif_tx_start_queue(q) ((q)->stopped = 0)
#define netif_tx_stop_queue(q) ((q)->stopped = 1)
#define netif_tx_wake_queue(q) ((q)->stopped = 0)
#define netif_tx_queue_stopped(q) ((q)->stopped)
#define netif_tx_lock(dev) do {} while (0)
#define netif_tx_unlock(dev) do {} while (0)
#define netif_tx_lock_bh(dev) do {} while (0)
#define netif_tx_unlock_bh(dev) do {} while (0)
#define netif_trans_update(dev) ((dev)->trans_start = jiffies)
#define netif_set_real_num_tx_queues(d, n) 0
#define netif_set_real_num_rx_queues(d, n) 0
#define netif_set_tso_max_size(d, s) do {} while (0)
#define netif_set_tso_max_segs(d, s) do {} while (0)
#define netif_set_gso_max_size(d, s) do {} while (0)
#define netdev_update_features(d) do {} while (0)
#define netdev_sent_queue(d, b) do {} while (0)
#define netdev_completed_queue(d, p, b) do {} while (0)
#define netdev_reset_queue(d) do {} while (0)
#define netdev_tx_sent_queue(q, b) do {} while (0)
#define netdev_tx_completed_queue(q, p, b) do {} while (0)
#define netdev_tx_reset_queue(q) do {} while (0)
#define netif_subqueue_maybe_stop(d, i, a, s, w) 0
#define netif_subqueue_completed_wake(d, i, p, b, a, s) do {} while (0)
#define dev_get_stats(d, s) (s)

/* сообщения */
#define netdev_printk(lvl, dev, fmt, ...) printk(lvl "%s: " fmt, netdev_name(dev), ##__VA_ARGS__)
#define netdev_emerg(dev, fmt, ...) netdev_printk(KERN_EMERG, dev, fmt, ##__VA_ARGS__)
#define netdev_crit(dev, fmt, ...) netdev_printk(KERN_CRIT, dev, fmt, ##__VA_ARGS__)
#define netdev_err(dev, fmt, ...) netdev_printk(KERN_ERR, dev, fmt, ##__VA_ARGS__)
#define netdev_warn(dev, fmt, ...) netdev_printk(KERN_WARNING, dev, fmt, ##__VA_ARGS__)
#define netdev_notice(dev, fmt, ...) netdev_printk(KERN_NOTICE, dev, fmt, ##__VA_ARGS__)
#define netdev_info(dev, fmt, ...) netdev_printk(KERN_INFO, dev, fmt, ##__VA_ARGS__)
#define netdev_dbg(dev, fmt, ...) no_printk(fmt, ##__VA_ARGS__)
#define netdev_vdbg netdev_dbg
#define netdev_err_once netdev_err
#define netdev_warn_once netdev_warn
#define netdev_info_once netdev_info
#define net_err_ratelimited pr_err
#define net_warn_ratelimited pr_warn
#define net_info_ratelimited pr_info
#define net_dbg_ratelimited pr_debug

enum {
	NETIF_MSG_DRV_BIT, NETIF_MSG_PROBE_BIT, NETIF_MSG_LINK_BIT, NETIF_MSG_TIMER_BIT,
	NETIF_MSG_IFDOWN_BIT, NETIF_MSG_IFUP_BIT, NETIF_MSG_RX_ERR_BIT, NETIF_MSG_TX_ERR_BIT,
	NETIF_MSG_TX_QUEUED_BIT, NETIF_MSG_INTR_BIT, NETIF_MSG_TX_DONE_BIT, NETIF_MSG_RX_STATUS_BIT,
	NETIF_MSG_PKTDATA_BIT, NETIF_MSG_HW_BIT, NETIF_MSG_WOL_BIT,
};
#define NETIF_MSG_DRV BIT(NETIF_MSG_DRV_BIT)
#define NETIF_MSG_PROBE BIT(NETIF_MSG_PROBE_BIT)
#define NETIF_MSG_LINK BIT(NETIF_MSG_LINK_BIT)
#define NETIF_MSG_TIMER BIT(NETIF_MSG_TIMER_BIT)
#define NETIF_MSG_IFDOWN BIT(NETIF_MSG_IFDOWN_BIT)
#define NETIF_MSG_IFUP BIT(NETIF_MSG_IFUP_BIT)
#define NETIF_MSG_RX_ERR BIT(NETIF_MSG_RX_ERR_BIT)
#define NETIF_MSG_TX_ERR BIT(NETIF_MSG_TX_ERR_BIT)
#define NETIF_MSG_TX_QUEUED BIT(NETIF_MSG_TX_QUEUED_BIT)
#define NETIF_MSG_INTR BIT(NETIF_MSG_INTR_BIT)
#define NETIF_MSG_TX_DONE BIT(NETIF_MSG_TX_DONE_BIT)
#define NETIF_MSG_RX_STATUS BIT(NETIF_MSG_RX_STATUS_BIT)
#define NETIF_MSG_PKTDATA BIT(NETIF_MSG_PKTDATA_BIT)
#define NETIF_MSG_HW BIT(NETIF_MSG_HW_BIT)
#define NETIF_MSG_WOL BIT(NETIF_MSG_WOL_BIT)
#define netif_msg_drv(p) ((p)->msg_enable & NETIF_MSG_DRV)
#define netif_msg_probe(p) ((p)->msg_enable & NETIF_MSG_PROBE)
#define netif_msg_link(p) ((p)->msg_enable & NETIF_MSG_LINK)
#define netif_msg_timer(p) ((p)->msg_enable & NETIF_MSG_TIMER)
#define netif_msg_ifdown(p) ((p)->msg_enable & NETIF_MSG_IFDOWN)
#define netif_msg_ifup(p) ((p)->msg_enable & NETIF_MSG_IFUP)
#define netif_msg_rx_err(p) ((p)->msg_enable & NETIF_MSG_RX_ERR)
#define netif_msg_tx_err(p) ((p)->msg_enable & NETIF_MSG_TX_ERR)
#define netif_msg_tx_queued(p) ((p)->msg_enable & NETIF_MSG_TX_QUEUED)
#define netif_msg_intr(p) ((p)->msg_enable & NETIF_MSG_INTR)
#define netif_msg_tx_done(p) ((p)->msg_enable & NETIF_MSG_TX_DONE)
#define netif_msg_rx_status(p) ((p)->msg_enable & NETIF_MSG_RX_STATUS)
#define netif_msg_pktdata(p) ((p)->msg_enable & NETIF_MSG_PKTDATA)
#define netif_msg_hw(p) ((p)->msg_enable & NETIF_MSG_HW)
#define netif_msg_wol(p) ((p)->msg_enable & NETIF_MSG_WOL)
static inline u32 netif_msg_init(int debug_value, int default_msg_enable_bits)
{
	if (debug_value < 0 || debug_value >= 32)
		return default_msg_enable_bits;
	if (debug_value == 0)
		return 0;
	return (1U << debug_value) - 1;
}
#define netif_level(level, priv, type, dev, fmt, ...) \
	do { if (netif_msg_##type(priv)) netdev_##level(dev, fmt, ##__VA_ARGS__); } while (0)
#define netif_emerg(p, t, d, f, ...) netif_level(emerg, p, t, d, f, ##__VA_ARGS__)
#define netif_crit(p, t, d, f, ...) netif_level(crit, p, t, d, f, ##__VA_ARGS__)
#define netif_err(p, t, d, f, ...) netif_level(err, p, t, d, f, ##__VA_ARGS__)
#define netif_warn(p, t, d, f, ...) netif_level(warn, p, t, d, f, ##__VA_ARGS__)
#define netif_notice(p, t, d, f, ...) netif_level(notice, p, t, d, f, ##__VA_ARGS__)
#define netif_info(p, t, d, f, ...) netif_level(info, p, t, d, f, ##__VA_ARGS__)
#define netif_dbg(p, t, d, f, ...) do { if (0) netif_level(info, p, t, d, f, ##__VA_ARGS__); } while (0)
#define netif_vdbg netif_dbg

/* ----- Ethernet ----- */
__be16 eth_type_trans(struct sk_buff *skb, struct net_device *dev);
static inline bool is_zero_ether_addr(const u8 *a) { return !(a[0] | a[1] | a[2] | a[3] | a[4] | a[5]); }
static inline bool is_multicast_ether_addr(const u8 *a) { return a[0] & 1; }
static inline bool is_unicast_ether_addr(const u8 *a) { return !is_multicast_ether_addr(a); }
static inline bool is_broadcast_ether_addr(const u8 *a) { return (a[0] & a[1] & a[2] & a[3] & a[4] & a[5]) == 0xff; }
static inline bool is_valid_ether_addr(const u8 *a) { return !is_multicast_ether_addr(a) && !is_zero_ether_addr(a); }
static inline void ether_addr_copy(u8 *d, const u8 *s) { memcpy(d, s, ETH_ALEN); }
static inline bool ether_addr_equal(const u8 *a, const u8 *b) { return !memcmp(a, b, ETH_ALEN); }
static inline void eth_zero_addr(u8 *a) { memset(a, 0, ETH_ALEN); }
static inline void eth_broadcast_addr(u8 *a) { memset(a, 0xff, ETH_ALEN); }
static inline void eth_random_addr(u8 *a)
{
	lde_random_bytes(a, ETH_ALEN);
	a[0] &= 0xfe;
	a[0] |= 0x02;
}
static inline void dev_addr_set(struct net_device *d, const u8 *a) { memcpy(d->lde_addr, a, d->addr_len); }
static inline void eth_hw_addr_set(struct net_device *d, const u8 *a) { memcpy(d->lde_addr, a, ETH_ALEN); }
static inline void dev_addr_mod(struct net_device *d, unsigned int o, const void *a, size_t n) { memcpy(d->lde_addr + o, a, n); }
static inline void eth_hw_addr_random(struct net_device *d)
{
	u8 a[ETH_ALEN];
	eth_random_addr(a);
	eth_hw_addr_set(d, a);
	d->addr_assign_type = NET_ADDR_RANDOM;
}
int eth_validate_addr(struct net_device *dev);
int eth_mac_addr(struct net_device *dev, void *p);
#define eth_prepare_mac_addr_change(d, p) 0
#define eth_commit_mac_addr_change(d, p) eth_mac_addr(d, p)
#define eth_platform_get_mac_address(d, a) (-ENODEV)
#define eth_header_parse NULL

#define netdev_WARN(dev, fmt, ...) WARN(1, "%s: " fmt, netdev_name(dev), ##__VA_ARGS__)
#define netdev_WARN_ONCE netdev_WARN

/* ----- заголовки IP ----- */
#define IPPROTO_IP 0
#define IPPROTO_ICMP 1
#define IPPROTO_TCP 6
#define IPPROTO_UDP 17
#define IPPROTO_IPV6 41
#define IPPROTO_ICMPV6 58
struct iphdr {
	u8 ihl : 4, version : 4;
	u8 tos;
	__be16 tot_len;
	__be16 id;
	__be16 frag_off;
	u8 ttl;
	u8 protocol;
	__sum16 check;
	__be32 saddr, daddr;
};
struct ipv6hdr {
	u8 priority : 4, version : 4;
	u8 flow_lbl[3];
	__be16 payload_len;
	u8 nexthdr;
	u8 hop_limit;
	u8 saddr[16], daddr[16];
};
struct tcphdr {
	__be16 source, dest;
	__be32 seq, ack_seq;
	u16 res1 : 4, doff : 4, fin : 1, syn : 1, rst : 1, psh : 1, ack : 1, urg : 1, ece : 1, cwr : 1;
	__be16 window;
	__sum16 check;
	__be16 urg_ptr;
};
struct udphdr {
	__be16 source, dest, len;
	__sum16 check;
};
#define skb_network_header(skb) ((skb)->head + (skb)->network_header)
#define skb_transport_header(skb) ((skb)->head + (skb)->transport_header)
#define ip_hdr(skb) ((struct iphdr *)skb_network_header(skb))
#define ipv6_hdr(skb) ((struct ipv6hdr *)skb_network_header(skb))
#define tcp_hdr(skb) ((struct tcphdr *)skb_transport_header(skb))
#define udp_hdr(skb) ((struct udphdr *)skb_transport_header(skb))
#define tcp_hdrlen(skb) (tcp_hdr(skb)->doff * 4)
#define skb_reset_network_header(skb) ((skb)->network_header = (skb)->data - (skb)->head)
#define skb_set_network_header(skb, o) ((skb)->network_header = (skb)->data - (skb)->head + (o))
#define skb_reset_transport_header(skb) ((skb)->transport_header = (skb)->data - (skb)->head)
#define vlan_features_check(skb, f) (f)
#define vlan_get_protocol(skb) ((skb)->protocol)

/* VLAN */
#define VLAN_HLEN 4
#define VLAN_ETH_HLEN 18
#define VLAN_ETH_FRAME_LEN 1518
#define VLAN_N_VID 4096
#define VLAN_VID_MASK 0x0fff
#define VLAN_PRIO_SHIFT 13

/* ----- ethtool ----- */
#define __ETHTOOL_DECLARE_LINK_MODE_MASK(name) DECLARE_BITMAP(name, __ETHTOOL_LINK_MODE_MASK_NBITS)
struct ethtool_link_ksettings {
	struct ethtool_link_settings base;
	struct {
		__ETHTOOL_DECLARE_LINK_MODE_MASK(supported);
		__ETHTOOL_DECLARE_LINK_MODE_MASK(advertising);
		__ETHTOOL_DECLARE_LINK_MODE_MASK(lp_advertising);
	} link_modes;
	u32 lanes;
};
#define ethtool_link_ksettings_zero_link_mode(ptr, name) \
	bitmap_zero((ptr)->link_modes.name, __ETHTOOL_LINK_MODE_MASK_NBITS)
#define ethtool_link_ksettings_add_link_mode(ptr, name, mode) \
	set_bit(ETHTOOL_LINK_MODE_##mode##_BIT, (ptr)->link_modes.name)
#define ethtool_link_ksettings_del_link_mode(ptr, name, mode) \
	clear_bit(ETHTOOL_LINK_MODE_##mode##_BIT, (ptr)->link_modes.name)
#define ethtool_link_ksettings_test_link_mode(ptr, name, mode) \
	test_bit(ETHTOOL_LINK_MODE_##mode##_BIT, (ptr)->link_modes.name)
void ethtool_convert_legacy_u32_to_link_mode(unsigned long *dst, u32 legacy_u32);
bool ethtool_convert_link_mode_to_legacy_u32(u32 *legacy_u32, const unsigned long *src);
u32 ethtool_op_get_link(struct net_device *dev);
#define ethtool_op_get_ts_info NULL
#define ethtool_sprintf(data, fmt, ...) \
	do { snprintf(*(data), ETH_GSTRING_LEN, fmt, ##__VA_ARGS__); *(data) += ETH_GSTRING_LEN; } while (0)
#define ethtool_puts(data, s) ethtool_sprintf(data, "%s", s)
struct netlink_ext_ack {
	const char *_msg;
};
#define NL_SET_ERR_MSG(e, m) do { if (e) (e)->_msg = (m); } while (0)
#define NL_SET_ERR_MSG_MOD NL_SET_ERR_MSG
struct kernel_ethtool_ringparam {
	u32 rx_buf_len;
	u8 tcp_data_split;
	u8 tx_push;
	u8 rx_push;
	u32 cqe_size;
	u32 tx_push_buf_len;
	u32 tx_push_buf_max_len;
};
struct kernel_ethtool_coalesce {
	u8 use_cqe_mode_tx;
	u8 use_cqe_mode_rx;
	u32 tx_aggr_max_bytes;
	u32 tx_aggr_max_frames;
	u32 tx_aggr_time_usecs;
};
struct ethtool_ops {
	u32 cap_link_lanes_supported : 1;
	u32 supported_coalesce_params;
	u32 supported_ring_params;
	void (*get_drvinfo)(struct net_device *, struct ethtool_drvinfo *);
	int (*get_regs_len)(struct net_device *);
	void (*get_regs)(struct net_device *, struct ethtool_regs *, void *);
	void (*get_wol)(struct net_device *, struct ethtool_wolinfo *);
	int (*set_wol)(struct net_device *, struct ethtool_wolinfo *);
	u32 (*get_msglevel)(struct net_device *);
	void (*set_msglevel)(struct net_device *, u32);
	int (*nway_reset)(struct net_device *);
	u32 (*get_link)(struct net_device *);
	int (*get_link_ext_state)(struct net_device *, void *);
	int (*get_eeprom_len)(struct net_device *);
	int (*get_eeprom)(struct net_device *, struct ethtool_eeprom *, u8 *);
	int (*set_eeprom)(struct net_device *, struct ethtool_eeprom *, u8 *);
	int (*get_coalesce)(struct net_device *, struct ethtool_coalesce *,
			    struct kernel_ethtool_coalesce *, struct netlink_ext_ack *);
	int (*set_coalesce)(struct net_device *, struct ethtool_coalesce *,
			    struct kernel_ethtool_coalesce *, struct netlink_ext_ack *);
	void (*get_ringparam)(struct net_device *, struct ethtool_ringparam *,
			      struct kernel_ethtool_ringparam *, struct netlink_ext_ack *);
	int (*set_ringparam)(struct net_device *, struct ethtool_ringparam *,
			     struct kernel_ethtool_ringparam *, struct netlink_ext_ack *);
	void (*get_pauseparam)(struct net_device *, struct ethtool_pauseparam *);
	int (*set_pauseparam)(struct net_device *, struct ethtool_pauseparam *);
	void (*self_test)(struct net_device *, struct ethtool_test *, u64 *);
	void (*get_strings)(struct net_device *, u32 stringset, u8 *);
	int (*set_phys_id)(struct net_device *, int);
	void (*get_ethtool_stats)(struct net_device *, struct ethtool_stats *, u64 *);
	int (*begin)(struct net_device *);
	void (*complete)(struct net_device *);
	int (*get_sset_count)(struct net_device *, int);
	int (*get_ts_info)(struct net_device *, void *);
	int (*get_eee)(struct net_device *, void *);
	int (*set_eee)(struct net_device *, void *);
	int (*get_link_ksettings)(struct net_device *, struct ethtool_link_ksettings *);
	int (*set_link_ksettings)(struct net_device *, const struct ethtool_link_ksettings *);
	void (*get_eth_mac_stats)(struct net_device *, void *);
	void (*get_eth_ctrl_stats)(struct net_device *, void *);
	void (*get_pause_stats)(struct net_device *, void *);
};
#define ETHTOOL_COALESCE_USECS BIT(0)
#define ETHTOOL_COALESCE_MAX_FRAMES BIT(1)
#define ETHTOOL_COALESCE_RX_USECS BIT(0)
#define ETHTOOL_COALESCE_RX_MAX_FRAMES BIT(1)
#define ETHTOOL_COALESCE_TX_USECS BIT(4)
#define ETHTOOL_COALESCE_TX_MAX_FRAMES BIT(5)

/* ----- linkmode ----- */
static inline void linkmode_zero(unsigned long *d) { bitmap_zero(d, __ETHTOOL_LINK_MODE_MASK_NBITS); }
static inline void linkmode_fill(unsigned long *d) { bitmap_fill(d, __ETHTOOL_LINK_MODE_MASK_NBITS); }
static inline void linkmode_copy(unsigned long *d, const unsigned long *s) { bitmap_copy(d, s, __ETHTOOL_LINK_MODE_MASK_NBITS); }
static inline void linkmode_and(unsigned long *d, const unsigned long *a, const unsigned long *b) { bitmap_and(d, a, b, __ETHTOOL_LINK_MODE_MASK_NBITS); }
static inline void linkmode_or(unsigned long *d, const unsigned long *a, const unsigned long *b) { bitmap_or(d, a, b, __ETHTOOL_LINK_MODE_MASK_NBITS); }
static inline bool linkmode_empty(const unsigned long *s) { return bitmap_empty(s, __ETHTOOL_LINK_MODE_MASK_NBITS); }
static inline bool linkmode_equal(const unsigned long *a, const unsigned long *b) { return bitmap_equal(a, b, __ETHTOOL_LINK_MODE_MASK_NBITS); }
#define linkmode_set_bit(nr, a) __set_bit(nr, a)
#define linkmode_clear_bit(nr, a) __clear_bit(nr, a)
#define linkmode_test_bit(nr, a) test_bit(nr, a)
static inline void linkmode_mod_bit(int nr, unsigned long *a, int set)
{
	if (set)
		linkmode_set_bit(nr, a);
	else
		linkmode_clear_bit(nr, a);
}
#define FLOW_CTRL_TX 0x01
#define FLOW_CTRL_RX 0x02

#endif
