// SPDX-License-Identifier: GPL-2.0
/* Quadrix LDE: строковые функции (memcpy/memset/memmove/memcmp даёт
 * compiler_builtins из Rust). */
#include <lde/kernel.h>

size_t strlen(const char *s)
{
	size_t n = 0;
	while (s[n])
		n++;
	return n;
}

size_t strnlen(const char *s, size_t max)
{
	size_t n = 0;
	while (n < max && s[n])
		n++;
	return n;
}

int strcmp(const char *a, const char *b)
{
	while (*a && *a == *b)
		a++, b++;
	return (unsigned char)*a - (unsigned char)*b;
}

int strncmp(const char *a, const char *b, size_t n)
{
	for (; n; n--, a++, b++) {
		if (*a != *b)
			return (unsigned char)*a - (unsigned char)*b;
		if (!*a)
			break;
	}
	return 0;
}

char *strchr(const char *s, int c)
{
	for (; *s; s++)
		if (*s == (char)c)
			return (char *)s;
	return c ? NULL : (char *)s;
}

void *memchr(const void *s, int c, size_t n)
{
	const u8 *p = s;
	for (size_t i = 0; i < n; i++)
		if (p[i] == (u8)c)
			return (void *)(p + i);
	return NULL;
}

char *strcpy(char *d, const char *s)
{
	char *r = d;
	while ((*d++ = *s++))
		;
	return r;
}

char *strncpy(char *d, const char *s, size_t n)
{
	size_t i = 0;
	for (; i < n && s[i]; i++)
		d[i] = s[i];
	for (; i < n; i++)
		d[i] = 0;
	return d;
}

size_t strlcpy(char *d, const char *s, size_t n)
{
	size_t len = strlen(s);
	if (n) {
		size_t c = len >= n ? n - 1 : len;
		memcpy(d, s, c);
		d[c] = 0;
	}
	return len;
}

ssize_t lde_strscpy(char *d, const char *s, size_t n)
{
	if (!n)
		return -E2BIG;
	size_t len = strnlen(s, n);
	if (len == n) {
		memcpy(d, s, n - 1);
		d[n - 1] = 0;
		return -E2BIG;
	}
	memcpy(d, s, len + 1);
	return len;
}

char *kstrdup(const char *s, gfp_t gfp)
{
	if (!s)
		return NULL;
	return kmemdup(s, strlen(s) + 1, gfp);
}

void *kmemdup(const void *s, size_t n, gfp_t gfp)
{
	void *p = kmalloc(n, gfp);
	if (p)
		memcpy(p, s, n);
	return p;
}

/* CRC-32 (IEEE 802.3), отражённый и прямой варианты */
u32 crc32_le(u32 crc, const unsigned char *p, size_t len)
{
	while (len--) {
		crc ^= *p++;
		for (int i = 0; i < 8; i++)
			crc = (crc >> 1) ^ (crc & 1 ? 0xedb88320 : 0);
	}
	return crc;
}

u32 crc32_be(u32 crc, const unsigned char *p, size_t len)
{
	while (len--) {
		crc ^= (u32)*p++ << 24;
		for (int i = 0; i < 8; i++)
			crc = (crc << 1) ^ (crc & 0x80000000 ? 0x04c11db7 : 0);
	}
	return crc;
}
