// SPDX-License-Identifier: GPL-2.0
/* Quadrix LDE: PCI-устройство процесса, модули, прерывания. lxdrv
 * обслуживает одно устройство: capability на него выдал init. */
#include <lde/kernel.h>

static struct pci_dev lde_pdev;
static struct pci_bus lde_bus;
static struct pci_driver *lde_driver;

struct lde_irq_handler {
	irq_handler_t handler;
	void *dev;
	const char *name;
};
static struct lde_irq_handler irq_handlers[4];
static int irq_disabled;
static bool irq_pending;

/* список функций module_init собирает build.rs */
extern int (*const lde_initcalls[])(void);
extern const int lde_ninitcalls;
extern const char *const lde_initcall_names[];

static bool id_match(const struct pci_device_id *id, const struct pci_dev *p)
{
	return (id->vendor == (u32)PCI_ANY_ID || id->vendor == p->vendor) &&
	       (id->device == (u32)PCI_ANY_ID || id->device == p->device) &&
	       (id->subvendor == (u32)PCI_ANY_ID || id->subvendor == p->subsystem_vendor) &&
	       (id->subdevice == (u32)PCI_ANY_ID || id->subdevice == p->subsystem_device) &&
	       !((id->class ^ p->class) & id->class_mask);
}

int pci_register_driver(struct pci_driver *drv)
{
	if (lde_driver)
		return 0;
	for (const struct pci_device_id *id = drv->id_table; id->vendor || id->device || id->class_mask; id++) {
		if (!id_match(id, &lde_pdev))
			continue;
		lde_pdev.dev.driver = &drv->driver;
		int r = drv->probe(&lde_pdev, id);
		if (r == 0) {
			lde_driver = drv;
			printk(KERN_INFO "драйвер %s взял устройство %04x:%04x\n", drv->name,
			       lde_pdev.vendor, lde_pdev.device);
		} else {
			printk(KERN_ERR "%s: probe завершился ошибкой %d\n", drv->name, r);
			lde_pdev.dev.driver = NULL;
		}
		break;
	}
	return 0;
}

void pci_unregister_driver(struct pci_driver *drv)
{
	if (lde_driver == drv) {
		if (drv->remove)
			drv->remove(&lde_pdev);
		lde_driver = NULL;
	}
}

const char *lde_driver_name(void)
{
	return lde_driver ? lde_driver->name : "";
}

int lde_setup(const struct lde_pci_info *info)
{
	struct pci_dev *p = &lde_pdev;
	p->bus = &lde_bus;
	p->vendor = info->vendor;
	p->device = info->device;
	p->subsystem_vendor = info->subvendor;
	p->subsystem_device = info->subdevice;
	p->revision = info->revision;
	p->class = (u32)info->class_code << 16 | (u32)info->subclass << 8 | info->prog_if;
	p->irq = info->irq;
	p->dma_mask = DMA_BIT_MASK(32);
	p->dev.dma_mask = &p->dma_mask;
	p->dev.coherent_dma_mask = DMA_BIT_MASK(32);
	p->dev.init_name = "pci0";
	for (int i = 0; i < 6; i++) {
		if (!info->bar_len[i])
			continue;
		p->resource[i].start = info->bar_start[i];
		p->resource[i].end = info->bar_start[i] + info->bar_len[i] - 1;
		p->resource[i].flags = info->bar_io[i] ? IORESOURCE_IO : IORESOURCE_MEM;
	}
	p->pcie_cap = pci_find_capability(p, PCI_CAP_ID_EXP);
	/* встроенные модули */
	for (int i = 0; i < lde_ninitcalls && !lde_driver; i++) {
		int r = lde_initcalls[i]();
		if (r)
			printk(KERN_ERR "модуль %s: ошибка %d\n", lde_initcall_names[i], r);
	}
	return lde_driver ? 0 : -ENODEV;
}

int lde_bound(void)
{
	return lde_driver != NULL;
}

int pci_enable_device(struct pci_dev *p)
{
	u16 cmd;
	pci_read_config_word(p, PCI_COMMAND, &cmd);
	cmd |= PCI_COMMAND_MEMORY | PCI_COMMAND_IO;
	cmd &= ~PCI_COMMAND_INTX_DISABLE;
	pci_write_config_word(p, PCI_COMMAND, cmd);
	return 0;
}

void pci_disable_device(struct pci_dev *p)
{
	pci_clear_master(p);
}

void pci_set_master(struct pci_dev *p)
{
	u16 cmd;
	pci_read_config_word(p, PCI_COMMAND, &cmd);
	pci_write_config_word(p, PCI_COMMAND, cmd | PCI_COMMAND_MASTER);
}

void pci_clear_master(struct pci_dev *p)
{
	u16 cmd;
	pci_read_config_word(p, PCI_COMMAND, &cmd);
	pci_write_config_word(p, PCI_COMMAND, cmd & ~PCI_COMMAND_MASTER);
}

int pci_read_config_byte(const struct pci_dev *p, int off, u8 *v) { *v = qx_pci_read(off, 1); return 0; }
int pci_read_config_word(const struct pci_dev *p, int off, u16 *v) { *v = qx_pci_read(off, 2); return 0; }
int pci_read_config_dword(const struct pci_dev *p, int off, u32 *v) { *v = qx_pci_read(off, 4); return 0; }
int pci_write_config_byte(const struct pci_dev *p, int off, u8 v) { qx_pci_write(off, 1, v); return 0; }
int pci_write_config_word(const struct pci_dev *p, int off, u16 v) { qx_pci_write(off, 2, v); return 0; }
int pci_write_config_dword(const struct pci_dev *p, int off, u32 v) { qx_pci_write(off, 4, v); return 0; }

int pci_find_capability(struct pci_dev *p, int cap)
{
	u16 status;
	pci_read_config_word(p, PCI_STATUS, &status);
	if (!(status & 0x10))
		return 0;
	u8 pos;
	pci_read_config_byte(p, PCI_CAPABILITY_LIST, &pos);
	for (int n = 0; pos >= 0x40 && n < 48; n++) {
		pos &= ~3;
		u8 id;
		pci_read_config_byte(p, pos, &id);
		if (id == cap)
			return pos;
		pci_read_config_byte(p, pos + 1, &pos);
	}
	return 0;
}

int pci_alloc_irq_vectors(struct pci_dev *p, unsigned int min, unsigned int max, unsigned int flags)
{
	return (flags & PCI_IRQ_INTX) && min <= 1 ? 1 : -ENOSPC;
}

void __iomem *pci_iomap(struct pci_dev *p, int bar, unsigned long max)
{
	if (bar < 0 || bar >= 6 || !p->resource[bar].end)
		return NULL;
	if (p->resource[bar].flags & IORESOURCE_IO)
		return (void __iomem *)(LDE_PIO_BASE + p->resource[bar].start);
	size_t len;
	return qx_iomap(bar, &len);
}

int request_irq(unsigned int irq, irq_handler_t h, unsigned long flags, const char *name, void *dev)
{
	for (unsigned i = 0; i < ARRAY_SIZE(irq_handlers); i++) {
		if (!irq_handlers[i].handler) {
			irq_handlers[i] = (struct lde_irq_handler){ h, dev, name };
			return 0;
		}
	}
	return -EBUSY;
}

int request_threaded_irq(unsigned int irq, irq_handler_t h, irq_handler_t t, unsigned long flags,
			 const char *name, void *dev)
{
	/* потоковый обработчик вызывается сразу после основного */
	return request_irq(irq, h ? h : t, flags, name, dev);
}

void free_irq(unsigned int irq, void *dev)
{
	for (unsigned i = 0; i < ARRAY_SIZE(irq_handlers); i++)
		if (irq_handlers[i].dev == dev)
			irq_handlers[i].handler = NULL;
}

void disable_irq(unsigned int irq)
{
	irq_disabled++;
}

void enable_irq(unsigned int irq)
{
	if (irq_disabled && !--irq_disabled && irq_pending)
		lde_irq();
}

void lde_irq(void)
{
	if (irq_disabled) {
		irq_pending = true;
		return;
	}
	irq_pending = false;
	for (unsigned i = 0; i < ARRAY_SIZE(irq_handlers); i++)
		if (irq_handlers[i].handler)
			irq_handlers[i].handler(lde_pdev.irq, irq_handlers[i].dev);
}

void __iomem *ioremap(resource_size_t phys, size_t size)
{
	/* физический адрес — внутри одного из BAR устройства */
	for (int i = 0; i < 6; i++) {
		struct resource *r = &lde_pdev.resource[i];
		if (!r->end || (r->flags & IORESOURCE_IO) || phys < r->start || phys > r->end)
			continue;
		size_t len;
		u8 __iomem *base = qx_iomap(i, &len);
		return base ? base + (phys - r->start) : NULL;
	}
	return NULL;
}
