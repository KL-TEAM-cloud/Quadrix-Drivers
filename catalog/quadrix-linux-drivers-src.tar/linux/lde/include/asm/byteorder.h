/* SPDX-License-Identifier: GPL-2.0 */
#include <lde/kernel.h>
