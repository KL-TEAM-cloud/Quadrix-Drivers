/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LDE_LINUX_IF_ETHER_H
#define _LDE_LINUX_IF_ETHER_H
#include <linux/types.h>
#include <uapi/linux/if_ether.h>
#endif
