// SPDX-License-Identifier: GPL-2.0
/* Quadrix LDE: время, таймеры и отложенная работа. Всё выполняется в
 * главном цикле lxdrv (lde_run). */
#include <lde/kernel.h>

static LIST_HEAD(timers);
static LIST_HEAD(works);

bool lde_napi_run(void);

unsigned long lde_jiffies(void)
{
	return qx_uptime_us() / 1000;
}

void lde_init_work(struct work_struct *w, work_func_t f)
{
	w->func = f;
	w->pending = 0;
	INIT_LIST_HEAD(&w->entry);
}

static void delayed_work_timer(struct timer_list *t)
{
	struct delayed_work *dw = container_of(t, struct delayed_work, timer);
	queue_work(system_wq, &dw->work);
}

void lde_init_delayed_work(struct delayed_work *w, work_func_t f)
{
	lde_init_work(&w->work, f);
	timer_setup(&w->timer, delayed_work_timer, 0);
}

bool queue_work(struct workqueue_struct *q, struct work_struct *w)
{
	if (w->pending)
		return false;
	w->pending = 1;
	list_add_tail(&w->entry, &works);
	return true;
}

bool queue_delayed_work(struct workqueue_struct *q, struct delayed_work *w, unsigned long delay)
{
	if (delayed_work_pending(w))
		return false;
	if (!delay)
		return queue_work(q, &w->work);
	mod_timer(&w->timer, jiffies + delay);
	return true;
}

bool mod_delayed_work(struct workqueue_struct *q, struct delayed_work *w, unsigned long delay)
{
	bool was = cancel_delayed_work(w);
	queue_delayed_work(q, w, delay);
	return was;
}

bool cancel_work_sync(struct work_struct *w)
{
	if (!w->pending)
		return false;
	list_del_init(&w->entry);
	w->pending = 0;
	return true;
}

bool cancel_delayed_work(struct delayed_work *w)
{
	bool t = del_timer(&w->timer);
	return cancel_work_sync(&w->work) || t;
}

bool cancel_delayed_work_sync(struct delayed_work *w)
{
	return cancel_delayed_work(w);
}

struct workqueue_struct *alloc_workqueue(const char *fmt, unsigned int flags, int max, ...)
{
	/* одна общая очередь: возвращается любой ненулевой указатель */
	static int dummy;
	return (struct workqueue_struct *)&dummy;
}

void timer_setup(struct timer_list *t, void (*fn)(struct timer_list *), unsigned int flags)
{
	t->function = fn;
	t->pending = 0;
	INIT_LIST_HEAD(&t->entry);
}

int mod_timer(struct timer_list *t, unsigned long expires)
{
	int was = t->pending;
	if (was)
		list_del(&t->entry);
	t->expires = expires;
	t->pending = 1;
	list_add_tail(&t->entry, &timers);
	return was;
}

int del_timer(struct timer_list *t)
{
	if (!t->pending)
		return 0;
	list_del_init(&t->entry);
	t->pending = 0;
	return 1;
}

u64 lde_run(void)
{
	for (int round = 0; round < 16; round++) {
		bool busy = false;
		/* истёкшие таймеры */
		unsigned long now = jiffies;
		struct timer_list *t, *tn;
		list_for_each_entry_safe(t, tn, &timers, entry) {
			if (time_after(t->expires, now))
				continue;
			list_del_init(&t->entry);
			t->pending = 0;
			t->function(t);
			busy = true;
			break; /* список мог измениться */
		}
		/* отложенная работа */
		while (!list_empty(&works)) {
			struct work_struct *w = list_first_entry(&works, struct work_struct, entry);
			list_del_init(&w->entry);
			w->pending = 0;
			w->func(w);
			busy = true;
		}
		busy |= lde_napi_run();
		if (!busy)
			break;
	}
	/* срок до ближайшего события */
	u64 wait = 1000000;
	unsigned long now = jiffies;
	struct timer_list *t;
	list_for_each_entry(t, &timers, entry) {
		long d = (long)(t->expires - now);
		u64 us = d <= 0 ? 0 : (u64)d * 1000;
		if (us < wait)
			wait = us;
	}
	if (!list_empty(&works))
		wait = 0;
	return wait;
}
