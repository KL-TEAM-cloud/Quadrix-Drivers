/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Quadrix LDE: граница между средой драйверов Linux (C) и процессом
 * lxdrv (Rust). Функции qx_* реализует Rust, функции lde_* — C.
 */
#ifndef _LDE_QX_H
#define _LDE_QX_H

#include <linux/types.h>

/* --- реализует lxdrv (Rust) --- */
void qx_log(const char *s, size_t len);
u64 qx_uptime_us(void);
void qx_delay_us(u64 us);
void *qx_alloc(size_t size);
void qx_free(const void *p);
size_t qx_alloc_size(const void *p);
u64 qx_virt_to_dma(const void *p);
void *qx_iomap(int bar, size_t *len);
u32 qx_port_in(u16 port, int width);
void qx_port_out(u16 port, int width, u32 value);
u32 qx_pci_read(int off, int width);
void qx_pci_write(int off, int width, u32 value);
void qx_net_rx(const void *data, size_t len);
void qx_net_carrier(int up);
void qx_random(void *buf, size_t len);
void qx_abort(void) __attribute__((noreturn));

/* --- реализует LDE (C) --- */
struct lde_pci_info {
	u16 vendor, device, subvendor, subdevice;
	u8 revision, prog_if, subclass, class_code;
	u32 irq;
	u64 bar_start[6];
	u64 bar_len[6];
	u32 bar_io[6];
};

/* описывает устройство и запускает встроенные модули; 0 — драйвер взял устройство */
int lde_setup(const struct lde_pci_info *info);
/* драйвер (встроенный или загруженный модуль) взял устройство */
int lde_bound(void);
/* есть сетевой интерфейс */
int lde_has_netdev(void);
const char *lde_driver_name(void);
void lde_net_mac(u8 mac[6]);
int lde_net_open(void);
/* обработчики прерывания устройства */
void lde_irq(void);
/* NAPI, отложенные задачи и таймеры; возвращает мкс до следующего срока */
u64 lde_run(void);
/* можно ли передать кадр */
int lde_tx_ready(void);
int lde_xmit(const void *data, size_t len);

#endif
