// SPDX-License-Identifier: GPL-2.0
/* Quadrix LDE: память. Вся память драйверов выделяется lxdrv из
 * физически непрерывных областей, доступных устройству для DMA (как
 * «нижняя» память Linux), поэтому kmalloc-буферы можно отдавать в
 * dma_map_single. */
#include <lde/kernel.h>

void *kmalloc(size_t size, gfp_t gfp)
{
	void *p = qx_alloc(size ? size : 1);
	if (p && (gfp & __GFP_ZERO))
		memset(p, 0, size);
	return p;
}

void kfree(const void *p)
{
	if (p && !IS_ERR(p))
		qx_free(p);
}

size_t ksize(const void *p)
{
	return p ? qx_alloc_size(p) : 0;
}

void *krealloc(const void *p, size_t size, gfp_t gfp)
{
	if (!p)
		return kmalloc(size, gfp);
	size_t old = ksize(p);
	if (size <= old)
		return (void *)p;
	void *n = kmalloc(size, gfp);
	if (n) {
		memcpy(n, p, old);
		kfree(p);
	}
	return n;
}

void *dma_alloc_coherent(struct device *d, size_t size, dma_addr_t *dma, gfp_t gfp)
{
	/* как в Linux: не меньше страницы, выровнено по странице */
	void *p = qx_alloc(ALIGN(size, PAGE_SIZE));
	if (!p)
		return NULL;
	memset(p, 0, size);
	*dma = qx_virt_to_dma(p);
	return p;
}

void dma_free_coherent(struct device *d, size_t size, void *cpu, dma_addr_t dma)
{
	kfree(cpu);
}

u32 lde_random_u32(void)
{
	u32 v;
	qx_random(&v, sizeof(v));
	return v;
}

void lde_random_bytes(void *p, size_t n)
{
	qx_random(p, n);
}

unsigned long lde_wait_for(unsigned int *done, unsigned long timeout)
{
	/* завершение ждётся из того же потока: выполняем отложенную работу,
	 * пока событие не наступит */
	unsigned long start = jiffies;
	while (!READ_ONCE(*done)) {
		if (time_after(jiffies, start + timeout))
			return 0;
		lde_irq();
		lde_run();
		qx_delay_us(100);
	}
	if (*done != (~0u >> 1))
		(*done)--;
	unsigned long left = start + timeout - jiffies;
	return left ? left : 1;
}
