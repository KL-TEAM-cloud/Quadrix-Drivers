/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LDE_LINUX_CONST_H
#define _LDE_LINUX_CONST_H
#include <uapi/linux/const.h>
#define UL(x) (_UL(x))
#define ULL(x) (_ULL(x))
#endif
